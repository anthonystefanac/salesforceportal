# Changes in this corrected package

## Blocking issues fixed

1. **Submit didn't work.** The page called `webapiSafeAjax(...)`, which was never
   defined, and relied on `{% webapi enable_safe_ajax: true %}`, which isn't a Power
   Pages Liquid tag I recognise. The page now includes Microsoft's standard
   `webapi.safeAjax` wrapper, which adds the anti-forgery token
   (`shell.getTokenDeferred()`) to the request.
2. **Missing required site setting.** `Webapi/asa_apprenticesignup/fields` was described
   as optional. It is required. The full column list is now in
   `security-and-permissions.md`.
3. **Submissions weren't linked to the applicant.** The Contact-scoped Table Permission
   needs a lookup from the table to Contact, and the record must be linked on create.
   Added the `asa_contact` lookup to the schema. The page now sends
   `asa_Contact@odata.bind` using the signed-in user's Contact id (`{{ user.id }}`).
   Also documented the web role assignment and the Contact (Self) Append To permission
   this needs.
4. **Staff access was described wrongly.** Table Permissions only apply to website
   users. The doc now uses Dataverse security roles for caseworkers.
5. **Column security would block website writes.** Documented the Power Pages column
   permissions needed alongside the Dataverse column security profile.

## Form behaviour fixes

- **Sign-in enforced.** Anonymous visitors see a "Sign in to continue" prompt instead
  of the form (in addition to the page permission).
- **Hidden answers no longer submitted.** Only fields currently shown are sent. A USI
  typed before switching to "No" is dropped.
- **Validation added**, with specific error messages, and focus moves to the first
  problem:
  - dates must be real `dd/mm/yyyy` dates (e.g. 31/02 is rejected);
  - postcodes are 4 digits;
  - USI is 10 valid characters (no I, O, 0 or 1) and is stored upper-case;
  - mobile numbers must be Australian;
  - email addresses must be well-formed;
  - year completed must be a 4-digit year, not in the future;
  - hours per week must be 1–168;
  - text is trimmed before saving.
- **Tracking code pre-fill** from the link: `?trackingcode=ABC123` (or `?code=`).
- **User input is escaped** when the page redraws. Quotes or `<` in an answer no longer
  break the field or inject markup.
- **Applicant-facing wording:** removed the internal reference to
  "security-and-permissions.md" from the public page.
- **No external calls:** removed Google Fonts; uses system fonts. (Later made optional; see "Matched to the ASA website".)
- **Date format:** today's date now shows in Australian format.
- Removed a stray `<title>` tag (the Power Pages page supplies the title).

## Schema changes (`dataverse-table-schema.csv`)

- New row: `asa_contact` — Lookup to Contact.
- 25 conditional columns changed from Required "Yes" to
  "No (form enforces when shown)", so staff aren't forced to fill in fields that
  don't apply.

## Added: table-creation script

`Create-ApprenticeSignUpTable.ps1` creates the table, all columns (with exact Choice
values), the column security flags and the Contact lookup from the CSV. It then
verifies everything and writes a web template with your names filled in. It was tested
against a mock Dataverse API covering: fresh create, re-run (all skipped), -WhatIf,
wrong prefix, throttling retry, and wrong Choice values being detected.

## Added: form and view script

`Build-ApprenticeSignUpForm.ps1` lays out the staff Main form (4 tabs, 13 sections,
all columns plus Owner), sets the Active view's columns and the Quick Find search
columns, adds them to the solution and publishes. It backs up the existing form
first and can restore it. It was tested against a mock Dataverse API covering:
plan-only, -WhatIf (no changes), apply, and restore from backup.

## Added: security and site settings script

`Configure-ApprenticeSignUpSecurity.ps1` creates:
- the two Web API site settings;
- the two Table Permissions (Contact scope, and Contact Self) linked to Authenticated Users;
- the Dataverse column security profile for the sensitive columns;
- optionally, the staff security role's privileges.

It discovers the Power Pages data model (enhanced `mspp_` or standard `adx_`) and the
real names from the environment's metadata before writing. It was tested against a mock
of both data models covering: plan-only, -WhatIf (no writes), apply, re-run (no
duplicates), multiple sites, a wrong site name, and the staff role option.

## Changed after testing in the dev environment

- **Table permission is now Global, Create only** (it was Contact scope plus a Contact
  Self permission). Linking the record to the applicant's Contact on create was
  refused by Power Pages (90040106).
- **The form no longer sets the Applicant (Contact) lookup** (`LINK_CONTACT = false`).
  Submissions save. Applicants are identified by tracking code and email.
- **The error screen shows a "Technical details" link** with the exact Power Pages
  error, for support.
- **The security script checks that the web role link actually stuck,** and prints an
  ACTION NEEDED step if it didn't. On the enhanced data model the link didn't persist
  and had to be added in Studio.
- **The form script** now edits views in place, and a view error no longer stops the
  form being published.

## Added: tracking-code check (open form, no sign-in)

- **The page checks the tracking code on the server** against the new **Sign Up Invites**
  table. It shows the form only for an Issued, unexpired code, locked read-only, and shows
  a friendly message otherwise.
- **`Enable-TrackingCodeCheck.ps1`** creates:
  - the invite table and its unique key;
  - Verification Status and an invite lookup on Apprentice Sign Up;
  - the anonymous read and create permissions.

  Tested against a mock: plan-only, -WhatIf, apply, re-run, and a role link that doesn't stick.
- **`TRACKING-CODE-CHECK.md`** covers:
  - opening the page;
  - building the verification flow, which marks codes Used and flags invalid or reused codes;
  - loading codes;
  - testing.
- **Tracking codes are generated automatically** by a Dataverse autonumber column, e.g.
  `ASA-10001-K7Q2ZP` (prefix, running number, 6 random characters). There's also an
  Applicant Name column and an optional flow that emails the link.
- The page's server-side (Liquid) check couldn't be run outside Power Pages. Its tags were
  checked for balance and the browser side was tested (locked code, submit), but use the
  checklist in TRACKING-CODE-CHECK.md to confirm it in dev.

## Polish

- **Standalone branded pages:** the form's "Use Website Header and Footer" setting is turned
  off, and there's a new **ASA Home** landing page (`asa-home.webtemplate.liquid`). It sends
  visitors who arrive with a code straight to the form.
- **With a valid code, the tracking-code step is skipped** and the code shows in the banner
  (12 sections).
- **Fixed a CSS bug** that stretched checkboxes and distorted radio dots.
- **Improved the mobile banner,** and added a footer with an optional privacy link.
- **The code-check messages** now use the branded layout.
- **The form no longer needs jQuery or the Power Pages `shell` script,** which aren't
  loaded when "Use Website Header and Footer" is off. It fetches the anti-forgery token
  from `/_layout/tokenhtml` itself and posts with `fetch`. The template now renders a
  complete HTML page, with its own `<title>` and mobile viewport.
- Setup steps are in `POLISH-SITE.md`.

## Matched to the ASA website

- **The logo** from the brand SVG is built into the page header, alongside a teal
  **1300 363 831** call button.
- **The colours** now come from the logo (teal, dark teal, cyan, orange, yellow, charcoal).
- **Website styling:** an uppercase charcoal heading with a yellow underline bar, the
  logo's triangle mark in the corner, yellow Next/Submit buttons, white cards on light
  grey, and a charcoal footer band.
- **The Figtree font** loads from Google Fonts. Set `asa_use_webfont` to `false` to use
  system fonts with no outside calls.
- The form logic, the code check and the submission are unchanged. They were re-tested:
  a full pass submits the same payload, and the error screen still shows its details.

## Tighter checks on key fields

- **Date of birth** and **Apprenticeship start date** use a date picker (a calendar), and
  can still be typed. Date of birth must be in the past.
- **Postcodes** (home, postal and parent/guardian) accept numbers only and must be exactly
  4 digits.
- **Mobile numbers** (applicant and parent/guardian) accept numbers only and must be
  10 digits starting with 0.
  - Spaces are removed automatically, so a pasted "0412 345 678" works.
  - "+61 412 345 678" is converted to 0412345678.
- **Email** must be a properly formed address, e.g. `name@example.com`. "jo@example",
  "jo.example.com" and "jo@@example.com" are rejected.
- **Phones bring up the number keypad** for postcode and mobile, and the email keyboard
  for email. Browsers can autofill these fields.
- The red * now sits next to the question instead of dropping below the hint.
- **Every date question now uses the date picker:** previous work started/ended,
  completed study started/finished, and current study start date.
  - These dates can't be in the future.
  - An end or finish date can't be before its start date.

## Matched to the October 2026 MS Forms form
(Details in `FORM-CROSSCHECK.md`; how to apply in `FORM-UPDATE-2026-10.md`.)

- **New "Government Requirements" section:** the Support Indicator quiz link, then the Quiz
  ID and the literacy and numeracy results (0–5).
- **New follow-up questions:**
  - country of legal residence (citizenship Other);
  - Born in Australia? (Australia / Other), then the country;
  - which language (language Other).
- **Choice lists now match the form:** gender, citizenship, Aboriginal/TSI, school level and
  highest schooling. Highest schooling uses national VET codes (2, 8–12).
- **USI:**
  - "Do you know your USI?", with a usi.gov.au link;
  - permission is now **Yes / No** (No allowed);
  - applicants can still submit without a USI.
- **Wording:** "Commenced before" now asks whether they've started *this qualification*
  before.
- **Required / optional:**
  - employer, start date, job title and workplace name are optional;
  - hours per week is required when shown.
- **Dates:**
  - the previous-work end date may be in the future;
  - completed-study dates are month and year (stored as the 1st of the month).
- **Pre-filled apprenticeship details are locked:** employer, start date, job title and
  qualification are read-only when staff filled them in.
- **Help text** from the MS Form throughout.
- **`Create-ApprenticeSignUpTable.ps1 -SyncChoices`** adds, relabels, reorders and removes
  Choice options to match the CSV. Verification now also flags options the CSV no longer lists.

## Staff form tidy-up

- **Applicant (Contact) is off the staff form.** It was only for the old sign-in design. The
  applicant's details live in Your Details / Contact Details. The column stays in the table,
  so nothing that refers to it breaks.
- **Staff Draft, Pre-filled and Changes From Pre-fill are read-only on the form.** The flows
  and the website set them.

## Verification flow: complete version (`VERIFY-FLOW.md`)

- One document with the whole flow: tracking-code check, clearing pre-fill, replacing drafts,
  plus a symptom-to-cause table for checking a hand-built flow.
- **New trigger condition:** run only for rows that have a tracking code. Staff drafts are
  created in the same table with no code, so without this they were flagged "Invalid code".

## Staff drafts: staff prepare, the applicant reviews and approves

- **One table:** staff create the Apprentice Sign Up record (Stage = Draft), fill in what they
  know or leave it blank, and set **Stage = Sent to applicant**.
- **A new "send to applicant" flow** creates the invite, linked to the draft, with a copy of
  the draft as the pre-fill. The existing email flow sends the link. Saving the draft again
  refreshes what the applicant sees.
- **The applicant must tick "I confirm the details above are correct"** on the review page,
  and the button now reads **Approve and submit**.
- **On a verified submission,** the verification flow marks the draft **Replaced** and makes
  it inactive. The approved record gets the draft's owner and a **Staff Draft** link.
- **Everything staff entered is pre-filled, including sensitive fields,** except Yes/No
  questions. Dataverse can't tell "not answered" from "No".
- **New `Enable-StaffDrafts.ps1`** adds Stage and the two Draft links, and makes the 21
  Business Required columns Optional so drafts can be saved part-filled. The website still
  requires every answer. The schema CSV now marks those columns "No (website requires it)".
- **`Build-ApprenticeSignUpForm.ps1`** puts Stage and Staff Draft on the form, and Stage in the
  Active view, when they exist.
- **The email-matching prefill flow and the test source table are no longer needed.** See
  **`STAFF-DRAFTS.md`**.

## Pre-fill from existing details, with a review page

- **The form can start pre-filled.** When staff create a Sign Up Invite, a flow finds the
  applicant's existing record by email address and copies the details you choose onto the
  invite (**Prefill Data**). The page reads it during the tracking-code check, so website
  visitors never get access to the source table. Consent boxes are never pre-filled.
- **New "Review your details" page** before Submit, for every applicant, pre-filled or not.
  - It lists every answer, with an **Edit** button per section.
  - **Save and review** returns the applicant to the review page.
  - Submit re-checks every section first.
- **Changes are recorded:** a pre-filled submission saves **Pre-filled = Yes** and **Changes
  From Pre-fill**. This lists each changed answer as old → new, and which blanks the
  applicant filled in. For Sensitive fields it only says that they changed.
- **The verification flow clears Prefill Data** once the sign-up is received.
- **New `Enable-Prefill.ps1`** adds the three columns and updates the Web API fields site
  setting. The two submission columns are also in `dataverse-table-schema.csv`.
- **`Create-ApprenticeSignUpTable.ps1` and `Build-ApprenticeSignUpForm.ps1` accept
  `-TableName`** to build a copy of the table. It's used for the test source table
  **Applicant Record (test)**.
- Setup, flow steps and tests are in **`PREFILL.md`**.
- Without pre-fill data, the form works exactly as before, apart from the new review page.

## Sign-in

All four scripts now re-login automatically if the saved Azure sign-in fails, and
accept `-Relogin` to force a fresh sign-in, so the manual Disconnect/Clear/Connect
commands aren't needed. Sign-in also works correctly in -WhatIf mode.

## How this was checked

The page was run in a headless browser, with jQuery and the Power Pages `shell` object
stubbed and the Web API call intercepted. A full 13-section pass submitted a correct
payload, including the anti-forgery token header, Choice numbers, ISO dates and the
Contact binding. Validation, hidden-field dropping, escaping and tracking-code pre-fill
were checked separately.

It has **not** been run against a real Power Pages site. The steps in
`README-deployment-guide.md` §6 are still needed in your dev environment.
