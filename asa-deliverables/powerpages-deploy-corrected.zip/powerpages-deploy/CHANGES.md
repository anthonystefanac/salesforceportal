# Changes in this corrected package

## Blocking issues fixed

1. **Submit didn't work.** The page called `webapiSafeAjax(...)`, which was never
   defined, and relied on `{% webapi enable_safe_ajax: true %}`, which isn't a Power
   Pages Liquid tag I recognise. The page now includes Microsoft's standard
   `webapi.safeAjax` wrapper, which adds the anti-forgery token
   (`shell.getTokenDeferred()`) to the request.
2. **Missing required site setting.** `Webapi/asa_apprenticesignup/fields` was described
   as optional. It is required. The full column list is now in
   `security-and-permissions.md`.
3. **Submissions weren't linked to the applicant.** The Contact-scoped Table Permission
   needs a lookup from the table to Contact, and the record must be linked on create.
   Added the `asa_contact` lookup to the schema. The page now sends
   `asa_Contact@odata.bind` using the signed-in user's Contact id (`{{ user.id }}`).
   Also documented the web role assignment and the Contact (Self) Append To permission
   this needs.
4. **Staff access was described wrongly.** Table Permissions only apply to website
   users. The doc now uses Dataverse security roles for caseworkers.
5. **Column security would block website writes.** Documented the Power Pages column
   permissions needed alongside the Dataverse column security profile.

## Form behaviour fixes

- **Sign-in enforced.** Anonymous visitors see a "Sign in to continue" prompt instead
  of the form (in addition to the page permission).
- **Hidden answers no longer submitted.** Only fields currently shown are sent. A USI
  typed before switching to "No" is dropped.
- **Validation added**, with specific error messages, and focus moves to the first
  problem:
  - dates must be real `dd/mm/yyyy` dates (e.g. 31/02 is rejected);
  - postcodes are 4 digits;
  - USI is 10 valid characters (no I, O, 0 or 1) and is stored upper-case;
  - mobile numbers must be Australian;
  - email addresses must be well-formed;
  - year completed must be a 4-digit year, not in the future;
  - hours per week must be 1–168;
  - text is trimmed before saving.
- **Tracking code pre-fill** from the link: `?trackingcode=ABC123` (or `?code=`).
- **User input is escaped** when the page redraws. Quotes or `<` in an answer no longer
  break the field or inject markup.
- **Applicant-facing wording:** removed the internal reference to
  "security-and-permissions.md" from the public page.
- **No external calls:** removed Google Fonts; uses system fonts. (Later made optional; see "Matched to the ASA website".)
- **Date format:** today's date now shows in Australian format.
- Removed a stray `<title>` tag (the Power Pages page supplies the title).

## Schema changes (`dataverse-table-schema.csv`)

- New row: `asa_contact` — Lookup to Contact.
- 25 conditional columns changed from Required "Yes" to
  "No (form enforces when shown)", so staff aren't forced to fill in fields that
  don't apply.

## Added: table-creation script

`Create-ApprenticeSignUpTable.ps1` creates the table, all columns (with exact Choice
values), the column security flags and the Contact lookup from the CSV. It then
verifies everything and writes a web template with your names filled in. It was tested
against a mock Dataverse API covering: fresh create, re-run (all skipped), -WhatIf,
wrong prefix, throttling retry, and wrong Choice values being detected.

## Added: form and view script

`Build-ApprenticeSignUpForm.ps1` lays out the staff Main form (4 tabs, 13 sections,
all columns plus Owner), sets the Active view's columns and the Quick Find search
columns, adds them to the solution and publishes. It backs up the existing form
first and can restore it. It was tested against a mock Dataverse API covering:
plan-only, -WhatIf (no changes), apply, and restore from backup.

## Added: security and site settings script

`Configure-ApprenticeSignUpSecurity.ps1` creates:
- the two Web API site settings;
- the two Table Permissions (Contact scope, and Contact Self) linked to Authenticated Users;
- the Dataverse column security profile for the sensitive columns;
- optionally, the staff security role's privileges.

It discovers the Power Pages data model (enhanced `mspp_` or standard `adx_`) and the
real names from the environment's metadata before writing. It was tested against a mock
of both data models covering: plan-only, -WhatIf (no writes), apply, re-run (no
duplicates), multiple sites, a wrong site name, and the staff role option.

## Changed after testing in the dev environment

- **Table permission is now Global, Create only** (it was Contact scope plus a Contact
  Self permission). Linking the record to the applicant's Contact on create was
  refused by Power Pages (90040106).
- **The form no longer sets the Applicant (Contact) lookup** (`LINK_CONTACT = false`).
  Submissions save. Applicants are identified by tracking code and email.
- **The error screen shows a "Technical details" link** with the exact Power Pages
  error, for support.
- **The security script checks that the web role link actually stuck,** and prints an
  ACTION NEEDED step if it didn't. On the enhanced data model the link didn't persist
  and had to be added in Studio.
- **The form script** now edits views in place, and a view error no longer stops the
  form being published.

## Added: tracking-code check (open form, no sign-in)

- **The page checks the tracking code on the server** against the new **Sign Up Invites**
  table. It shows the form only for an Issued, unexpired code, locked read-only, and shows
  a friendly message otherwise.
- **`Enable-TrackingCodeCheck.ps1`** creates:
  - the invite table and its unique key;
  - Verification Status and an invite lookup on Apprentice Sign Up;
  - the anonymous read and create permissions.

  Tested against a mock: plan-only, -WhatIf, apply, re-run, and a role link that doesn't stick.
- **`TRACKING-CODE-CHECK.md`** covers:
  - opening the page;
  - building the verification flow, which marks codes Used and flags invalid or reused codes;
  - loading codes;
  - testing.
- **Tracking codes are generated automatically** by a Dataverse autonumber column, e.g.
  `ASA-10001-K7Q2ZP` (prefix, running number, 6 random characters). There's also an
  Applicant Name column and an optional flow that emails the link.
- The page's server-side (Liquid) check couldn't be run outside Power Pages. Its tags were
  checked for balance and the browser side was tested (locked code, submit), but use the
  checklist in TRACKING-CODE-CHECK.md to confirm it in dev.

## Polish

- **Standalone branded pages:** the form's "Use Website Header and Footer" setting is turned
  off, and there's a new **ASA Home** landing page (`asa-home.webtemplate.liquid`). It sends
  visitors who arrive with a code straight to the form.
- **With a valid code, the tracking-code step is skipped** and the code shows in the banner
  (12 sections).
- **Fixed a CSS bug** that stretched checkboxes and distorted radio dots.
- **Improved the mobile banner,** and added a footer with an optional privacy link.
- **The code-check messages** now use the branded layout.
- **The form no longer needs jQuery or the Power Pages `shell` script,** which aren't
  loaded when "Use Website Header and Footer" is off. It fetches the anti-forgery token
  from `/_layout/tokenhtml` itself and posts with `fetch`. The template now renders a
  complete HTML page, with its own `<title>` and mobile viewport.
- Setup steps are in `POLISH-SITE.md`.

## Matched to the ASA website

- **The logo** from the brand SVG is built into the page header, alongside a teal
  **1300 363 831** call button.
- **The colours** now come from the logo (teal, dark teal, cyan, orange, yellow, charcoal).
- **Website styling:** an uppercase charcoal heading with a yellow underline bar, the
  logo's triangle mark in the corner, yellow Next/Submit buttons, white cards on light
  grey, and a charcoal footer band.
- **The Figtree font** loads from Google Fonts. Set `asa_use_webfont` to `false` to use
  system fonts with no outside calls.
- The form logic, the code check and the submission are unchanged. They were re-tested:
  a full pass submits the same payload, and the error screen still shows its details.

## Tighter checks on key fields

- **Date of birth** and **Apprenticeship start date** use a date picker (a calendar), and
  can still be typed. Date of birth must be in the past.
- **Postcodes** (home, postal and parent/guardian) accept numbers only and must be exactly
  4 digits.
- **Mobile numbers** (applicant and parent/guardian) accept numbers only and must be
  10 digits starting with 0.
  - Spaces are removed automatically, so a pasted "0412 345 678" works.
  - "+61 412 345 678" is converted to 0412345678.
- **Email** must be a properly formed address, e.g. `name@example.com`. "jo@example",
  "jo.example.com" and "jo@@example.com" are rejected.
- **Phones bring up the number keypad** for postcode and mobile, and the email keyboard
  for email. Browsers can autofill these fields.
- The red * now sits next to the question instead of dropping below the hint.
- The other date questions (previous work, study dates) are still typed as dd/mm/yyyy.
  They can be switched to the date picker the same way if wanted.

## Sign-in

All four scripts now re-login automatically if the saved Azure sign-in fails, and
accept `-Relogin` to force a fresh sign-in, so the manual Disconnect/Clear/Connect
commands aren't needed. Sign-in also works correctly in -WhatIf mode.

## How this was checked

The page was run in a headless browser, with jQuery and the Power Pages `shell` object
stubbed and the Web API call intercepted. A full 13-section pass submitted a correct
payload, including the anti-forgery token header, Choice numbers, ISO dates and the
Contact binding. Validation, hidden-field dropping, escaping and tracking-code pre-fill
were checked separately.

It has **not** been run against a real Power Pages site. The steps in
`README-deployment-guide.md` §6 are still needed in your dev environment.
