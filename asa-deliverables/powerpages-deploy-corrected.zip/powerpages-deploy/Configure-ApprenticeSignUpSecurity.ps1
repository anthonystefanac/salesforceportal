<#
.SYNOPSIS
    Creates the Power Pages site settings, table permissions and Dataverse column
    security for the Apprentice Sign Up form.

.DESCRIPTION
    Run this AFTER Create-ApprenticeSignUpTable.ps1, against the environment that
    holds your Power Pages site. It:

      Website (Power Pages)
        1. Webapi/<prefix>_apprenticesignup/enabled = true
        2. Webapi/<prefix>_apprenticesignup/fields  = every column the page writes
           (optionally Webapi/contact/enabled + fields, with -EnableContactWebApi)
        3. Table permission "Apprentice Sign Up - own records":
             Global scope, Create only - applicants can submit but can't read any record
        4. Assigns it to the site's "Authenticated Users" web role (and checks it stuck)

      Dataverse (staff side)
        6. Column security profile (default name "ASA Case Managers") with
           Read / Create / Update on every column marked Sensitive in the CSV
        7. Optional (-StaffRoleName): gives that security role Organisation-level
           Create / Read / Write / Append / Append To / Assign on Apprentice Sign Up

    It works with both Power Pages data models (enhanced "mspp_" and standard "adx_").
    It reads the real table, column and relationship names from your environment first,
    and stops before changing anything if something doesn't match.
    Safe to re-run: existing records are found and updated or skipped, not duplicated.

    NOT done by this script (it prints a checklist at the end):
      - adding staff users to the column security profile
      - Power Pages *column permissions* (Studio > Security > Column permissions)
      - restricting the page to Authenticated Users, and Entra sign-in

    Modes:
      -PlanOnly   No connection. Prints what would be created.
      -WhatIf     Connects and checks everything, but creates nothing.
      (neither)   Creates / updates the records.

.EXAMPLE
    .\Configure-ApprenticeSignUpSecurity.ps1 -Prefix bnsw -PlanOnly

.EXAMPLE
    .\Configure-ApprenticeSignUpSecurity.ps1 -EnvironmentUrl https://yourorg-dev.crm6.dynamics.com `
        -SolutionUniqueName ASATestAIApp -Prefix bnsw -WebsiteName "ASA Sign Up" -WhatIf

.EXAMPLE
    .\Configure-ApprenticeSignUpSecurity.ps1 -EnvironmentUrl https://yourorg-dev.crm6.dynamics.com `
        -SolutionUniqueName ASATestAIApp -Prefix bnsw -WebsiteName "ASA Sign Up" `
        -StaffRoleName "ASA Caseworker"

.NOTES
    Same requirements and sign-in as Create-ApprenticeSignUpTable.ps1.
    Run it in DEV first. After it finishes, open Power Pages Studio and click Sync
    (or Preview) so the site picks up the new settings.
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string] $EnvironmentUrl,
    [string] $SolutionUniqueName,
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[A-Za-z][A-Za-z0-9]{1,7}$')]
    [string] $Prefix,
    [string] $WebsiteName,
    [string] $StaffProfileName = 'ASA Case Managers',
    [string] $StaffRoleName,
    [switch] $EnableContactWebApi,
    [string] $CsvPath = (Join-Path $PSScriptRoot 'dataverse-table-schema.csv'),
    [string] $TenantId,
    [string] $AccessToken,
    [switch] $Relogin,
    [switch] $PlanOnly
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$Prefix       = $Prefix.ToLowerInvariant()
$TableLogical = "${Prefix}_apprenticesignup"
$LookupAttr   = "${Prefix}_contact"
$PermOwnName  = 'Apprentice Sign Up - own records'
$PermSelfName = 'Contact - self (for linking sign-ups)'

# ---------------------------------------------------------------------------
# CSV: column list for the fields setting, and the Sensitive columns
# ---------------------------------------------------------------------------
if (-not (Test-Path $CsvPath)) { throw "CSV not found: $CsvPath" }
$allCols = @(); $sensitive = @()
foreach ($r in (Import-Csv -Path $CsvPath -Encoding UTF8)) {
    $v = @($r.PSObject.Properties.Value)
    $logical = ($v[2].Trim() -replace '^asa_', "${Prefix}_").ToLowerInvariant()
    $allCols += $logical
    if ($v[6].Trim() -eq 'Yes') { $sensitive += $logical }
}
$fieldsValue = $allCols -join ','

$siteSettings = [ordered]@{
    "Webapi/$TableLogical/enabled" = 'true'
    "Webapi/$TableLogical/fields"  = $fieldsValue
}
if ($EnableContactWebApi) {
    $siteSettings['Webapi/contact/enabled'] = 'true'
    $siteSettings['Webapi/contact/fields']  = 'contactid'
}

if ($PlanOnly) {
    Write-Host "PLAN ONLY - nothing will be changed.`n" -ForegroundColor Cyan
    Write-Host "Website: $(if ($WebsiteName) { $WebsiteName } else { '(the only site in the environment, or pass -WebsiteName)' })" -ForegroundColor Cyan
    Write-Host "Site settings:"
    foreach ($k in $siteSettings.Keys) {
        $val = $siteSettings[$k]; if ($val.Length -gt 70) { $val = $val.Substring(0, 70) + "... ($($allCols.Count) columns)" }
        Write-Host "  $k = $val"
    }
    Write-Host "Table permissions (web role: Authenticated Users):"
    Write-Host "  '$PermOwnName'  table $TableLogical, scope Global, Create only (no Read)"
    Write-Host "Column security profile '$StaffProfileName': Read/Create/Update on $($sensitive.Count) columns:"
    Write-Host "  $($sensitive -join ', ')"
    if ($StaffRoleName) { Write-Host "Security role '$StaffRoleName': Organisation-level Create/Read/Write/Append/Append To/Assign on $TableLogical" }
    return
}

if (-not $EnvironmentUrl -or -not $SolutionUniqueName) {
    throw "-EnvironmentUrl and -SolutionUniqueName are required (or use -PlanOnly)."
}
$EnvironmentUrl = $EnvironmentUrl.TrimEnd('/')
$Api = "$EnvironmentUrl/api/data/v9.2"

# ---------------------------------------------------------------------------
# Authentication (same as the other scripts)
# ---------------------------------------------------------------------------
if (-not $AccessToken) {
    if (-not (Get-Module -ListAvailable -Name Az.Accounts)) {
        throw "Az.Accounts module not found. Run:  Install-Module Az.Accounts -Scope CurrentUser   (or pass -AccessToken)."
    }
    Import-Module Az.Accounts -ErrorAction Stop

    # Sign-in commands must really run even when the script runs with -WhatIf,
    # so pass -WhatIf:$false to every command that supports it.
    function Get-NoWhatIf([string] $name, [hashtable] $a) {
        if ((Get-Command $name).Parameters.ContainsKey('WhatIf')) { $a.WhatIf = $false }
        $a
    }
    function Connect-AzLogin {
        Write-Host "Signing in$(if ($TenantId) { " to $TenantId" })..." -ForegroundColor Cyan
        $connectArgs = Get-NoWhatIf 'Connect-AzAccount' @{ ErrorAction = 'Stop' }
        if ($TenantId) { $connectArgs.TenantId = $TenantId }
        Connect-AzAccount @connectArgs | Out-Null
    }
    function Clear-AzLogin {
        $d = Get-NoWhatIf 'Disconnect-AzAccount' @{ ErrorAction = 'SilentlyContinue' }
        Disconnect-AzAccount @d | Out-Null
        $c = Get-NoWhatIf 'Clear-AzContext' @{ Force = $true; ErrorAction = 'SilentlyContinue' }
        Clear-AzContext @c | Out-Null
    }

    if ($Relogin) {
        Write-Host "Clearing the previous sign-in (-Relogin)..." -ForegroundColor Cyan
        Clear-AzLogin
    }
    if (-not (Get-AzContext -ErrorAction SilentlyContinue)) { Connect-AzLogin }

    $tok = $null
    try {
        $tok = Get-AzAccessToken -ResourceUrl $EnvironmentUrl -ErrorAction Stop
    } catch {
        Write-Warning "The saved sign-in didn't work ($($_.Exception.Message)). Signing in again..."
        Clear-AzLogin
        Connect-AzLogin
        try {
            $tok = Get-AzAccessToken -ResourceUrl $EnvironmentUrl -ErrorAction Stop
        } catch {
            throw "Could not get a token for $EnvironmentUrl after signing in again: $($_.Exception.Message)`nCheck you signed in with your work account, try adding -TenantId businessnsw.com, and check your account has a security role in this environment. Or pass -AccessToken."
        }
    }
    if ($tok.Token -is [System.Security.SecureString]) {
        $AccessToken = [System.Net.NetworkCredential]::new('', $tok.Token).Password
    } else {
        $AccessToken = $tok.Token
    }
}

function Invoke-Dv {
    param([string] $Method, [string] $Path, $Body, [switch] $AllowNotFound)
    $headers = @{
        Authorization      = "Bearer $AccessToken"
        Accept             = 'application/json'
        'OData-MaxVersion' = '4.0'
        'OData-Version'    = '4.0'
        'MSCRM.SolutionUniqueName' = $SolutionUniqueName
        Prefer             = 'return=representation'
    }
    $req = @{ Method = $Method; Uri = "$Api/$Path"; Headers = $headers }
    if ($null -ne $Body) {
        $json = $Body | ConvertTo-Json -Depth 30 -Compress
        $req.Body        = [System.Text.Encoding]::UTF8.GetBytes($json)
        $req.ContentType = 'application/json; charset=utf-8'
    }
    for ($attempt = 1; ; $attempt++) {
        try {
            return Invoke-RestMethod @req
        } catch {
            $status = 0
            $respProp = $_.Exception.PSObject.Properties['Response']
            if ($respProp -and $respProp.Value) { $status = [int]$respProp.Value.StatusCode }
            if ($status -eq 404 -and $AllowNotFound) { return $null }
            $detail = if ($_.ErrorDetails) { $_.ErrorDetails.Message } else { $null }
            if (-not $detail) { $detail = $_.Exception.Message }
            $retryable = $status -eq 429 -or $status -ge 500 -or $detail -match 'another.*(customization|publish).*running|0x80071151'
            if ($retryable -and $attempt -lt 6) {
                $wait = [math]::Min(60, [math]::Pow(2, $attempt) * 2)
                Write-Warning "  $Method $Path returned $status - retrying in $wait s ($attempt/5)"
                Start-Sleep -Seconds $wait
                continue
            }
            throw "Dataverse $Method $Path failed ($status): $detail"
        }
    }
}

function Q([string] $s) { $s.Replace("'", "''") }   # escape for OData string literals

function Get-TableMeta([string] $logical) {
    $e = Invoke-Dv GET "EntityDefinitions(LogicalName='$logical')?`$select=LogicalName,EntitySetName,PrimaryIdAttribute,PrimaryNameAttribute" -AllowNotFound
    if (-not $e) { return $null }
    $a   = Invoke-Dv GET "EntityDefinitions(LogicalName='$logical')/Attributes?`$select=LogicalName"
    $m2o = Invoke-Dv GET "EntityDefinitions(LogicalName='$logical')/ManyToOneRelationships?`$select=SchemaName,ReferencingAttribute,ReferencingEntityNavigationPropertyName,ReferencedEntity"
    [pscustomobject]@{
        Logical = $logical; Set = $e.EntitySetName; Id = $e.PrimaryIdAttribute; Name = $e.PrimaryNameAttribute
        Attrs = @($a.value | ForEach-Object { $_.LogicalName }); M2O = @($m2o.value)
    }
}
function Assert-Attrs($meta, [string[]] $names) {
    $miss = @($names | Where-Object { $meta.Attrs -notcontains $_ })
    if ($miss) { throw "Table $($meta.Logical) has no column(s): $($miss -join ', '). Your Power Pages version may differ - nothing was changed. Send this message to whoever supports the script." }
}
function Get-NavProp($meta, [string] $attr) {
    $rel = @($meta.M2O | Where-Object { $_.ReferencingAttribute -eq $attr }) | Select-Object -First 1
    if (-not $rel) { throw "No lookup relationship for $($meta.Logical).$attr" }
    $rel.ReferencingEntityNavigationPropertyName
}
function Get-All($meta, [string] $select) {
    @((Invoke-Dv GET "$($meta.Set)?`$select=$select").value)
}

$created = 0; $updated = 0; $skipped = 0
$manualRoles = @()

# ---------------------------------------------------------------------------
# 1. Apprentice table + Contact relationship
# ---------------------------------------------------------------------------
Write-Host "Checking $TableLogical..." -ForegroundColor Cyan
$appMeta = Get-TableMeta $TableLogical
if (-not $appMeta) { throw "Table $TableLogical not found - run Create-ApprenticeSignUpTable.ps1 first, and check -Prefix." }
$contactRel = @($appMeta.M2O | Where-Object { $_.ReferencingAttribute -eq $LookupAttr -and $_.ReferencedEntity -eq 'contact' }) | Select-Object -First 1
if (-not $contactRel) { throw "No Contact lookup ($LookupAttr) on $TableLogical - re-run Create-ApprenticeSignUpTable.ps1." }
$missingCols = @($allCols | Where-Object { $appMeta.Attrs -notcontains $_ })
if ($missingCols) { throw "Columns missing from ${TableLogical}: $($missingCols -join ', '). Re-run Create-ApprenticeSignUpTable.ps1 (it adds missing columns and skips existing ones)$(if (@($missingCols | Where-Object { $_ -like '*prefill*' })) { ', or run Enable-Prefill.ps1' })." }
Write-Host "  OK - relationship $($contactRel.SchemaName)"

# ---------------------------------------------------------------------------
# 2. Which Power Pages data model, and which website
# ---------------------------------------------------------------------------
Write-Host "Finding the Power Pages site..." -ForegroundColor Cyan
$P = $null; $siteMeta = $null; $site = $null
foreach ($candidate in @('mspp', 'adx')) {
    $m = Get-TableMeta "${candidate}_website"
    if (-not $m) { continue }
    $sites = Get-All $m "$($m.Id),$($m.Name)"
    if ($WebsiteName) { $sites = @($sites | Where-Object { $_.($m.Name) -eq $WebsiteName }) }
    if ($sites.Count -eq 1) { $P = $candidate; $siteMeta = $m; $site = $sites[0]; break }
    if ($sites.Count -gt 1) {
        $names = ($sites | ForEach-Object { "'" + $_.($m.Name) + "'" }) -join ', '
        throw "More than one Power Pages site found ($names). Re-run with -WebsiteName `"<one of these>`"."
    }
}
if (-not $site) {
    throw "No Power Pages site$(if ($WebsiteName) { " named '$WebsiteName'" }) found in this environment. Check -EnvironmentUrl and -WebsiteName (the site name shown in Power Pages)."
}
$siteId   = $site.($siteMeta.Id)
$siteName = $site.($siteMeta.Name)
Write-Host "  OK - '$siteName' ($(if ($P -eq 'mspp') { 'enhanced data model' } else { 'standard data model' }))"

$settingMeta = Get-TableMeta "${P}_sitesetting"
$permMeta    = Get-TableMeta "${P}_entitypermission"
$roleMeta    = Get-TableMeta "${P}_webrole"
foreach ($pair in @(@($settingMeta, 'sitesetting'), @($permMeta, 'entitypermission'), @($roleMeta, 'webrole'))) {
    if (-not $pair[0]) { throw "Table ${P}_$($pair[1]) not found - unexpected Power Pages setup. Nothing was changed." }
}
Assert-Attrs $settingMeta @("${P}_value", "${P}_websiteid")
Assert-Attrs $roleMeta    @("${P}_authenticatedusersrole", "${P}_websiteid")
Assert-Attrs $permMeta    @("${P}_entitylogicalname", "${P}_scope", "${P}_read", "${P}_create", "${P}_write",
                            "${P}_delete", "${P}_append", "${P}_appendto", "${P}_contactrelationship", "${P}_websiteid")
$siteKey       = "_${P}_websiteid_value"
$settingSiteNv = Get-NavProp $settingMeta "${P}_websiteid"
$permSiteNv    = Get-NavProp $permMeta    "${P}_websiteid"

# Scope option values (read from the environment, by label)
$scopeAttr = Invoke-Dv GET "EntityDefinitions(LogicalName='${P}_entitypermission')/Attributes(LogicalName='${P}_scope')/Microsoft.Dynamics.CRM.PicklistAttributeMetadata?`$select=LogicalName&`$expand=OptionSet(`$select=Options)"
$scope = @{}
foreach ($o in $scopeAttr.OptionSet.Options) {
    $lbl = $o.Label.UserLocalizedLabel.Label
    if ($lbl) { $scope[$lbl] = [int]$o.Value }
}
foreach ($need in @('Global')) {
    if (-not $scope.ContainsKey($need)) { throw "Table permission scope '$need' not found (found: $($scope.Keys -join ', '))." }
}

# Table permission <-> web role N:N relationship
$m2m = Invoke-Dv GET "EntityDefinitions(LogicalName='${P}_entitypermission')/ManyToManyRelationships?`$select=SchemaName,Entity1LogicalName,Entity2LogicalName,Entity1NavigationPropertyName,Entity2NavigationPropertyName"
$roleRel = @($m2m.value | Where-Object {
    ($_.Entity1LogicalName -eq "${P}_entitypermission" -and $_.Entity2LogicalName -eq "${P}_webrole") -or
    ($_.Entity2LogicalName -eq "${P}_entitypermission" -and $_.Entity1LogicalName -eq "${P}_webrole") }) | Select-Object -First 1
if (-not $roleRel) { throw "No relationship between ${P}_entitypermission and ${P}_webrole found." }
$roleNav = if ($roleRel.Entity1LogicalName -eq "${P}_entitypermission") { $roleRel.Entity1NavigationPropertyName } else { $roleRel.Entity2NavigationPropertyName }

# Authenticated Users web role for this site
$roles = @(Get-All $roleMeta "$($roleMeta.Id),$($roleMeta.Name),${P}_authenticatedusersrole,$siteKey" |
           Where-Object { $_.$siteKey -eq $siteId -and $_."${P}_authenticatedusersrole" -eq $true })
if ($roles.Count -eq 0) { throw "No 'Authenticated Users' web role found for site '$siteName'." }
$authRole   = $roles[0]
$authRoleId = $authRole.($roleMeta.Id)
Write-Host "  Web role: '$($authRole.($roleMeta.Name))'"

# ---------------------------------------------------------------------------
# 3. Site settings
# ---------------------------------------------------------------------------
Write-Host "Site settings..." -ForegroundColor Cyan
$existingSettings = @(Get-All $settingMeta "$($settingMeta.Id),$($settingMeta.Name),${P}_value,$siteKey" | Where-Object { $_.$siteKey -eq $siteId })
foreach ($name in $siteSettings.Keys) {
    $value = $siteSettings[$name]
    $hit = @($existingSettings | Where-Object { $_.($settingMeta.Name) -eq $name }) | Select-Object -First 1
    if ($hit) {
        if ($hit."${P}_value" -eq $value) {
            Write-Host "  $name - already set" -ForegroundColor DarkGray; $skipped++
        } elseif ($PSCmdlet.ShouldProcess($name, 'Update site setting value')) {
            # Send name + website too: the enhanced data model refuses a value-only update (0x80040224)
            Invoke-Dv PATCH "$($settingMeta.Set)($($hit.($settingMeta.Id)))" @{
                $settingMeta.Name           = $name
                "${P}_value"                = $value
                "$settingSiteNv@odata.bind" = "/$($siteMeta.Set)($siteId)"
            } | Out-Null
            Write-Host "  $name - updated" -ForegroundColor Green; $updated++
        }
    } elseif ($PSCmdlet.ShouldProcess($name, 'Create site setting')) {
        Invoke-Dv POST $settingMeta.Set @{
            $settingMeta.Name                = $name
            "${P}_value"                     = $value
            "$settingSiteNv@odata.bind"      = "/$($siteMeta.Set)($siteId)"
        } | Out-Null
        Write-Host "  $name - created" -ForegroundColor Green; $created++
    }
}

# ---------------------------------------------------------------------------
# 4. Table permissions + web role
# ---------------------------------------------------------------------------
Write-Host "Table permissions..." -ForegroundColor Cyan
$existingPerms = @(Get-All $permMeta "$($permMeta.Id),$($permMeta.Name),$siteKey" | Where-Object { $_.$siteKey -eq $siteId })

# Global scope, Create only: applicants can submit but never read any record (including their own).
# (Contact scope needs the record linked to the contact on create, which Power Pages refused
#  with 90040106 in testing - so the form doesn't link it; see LINK_CONTACT in the web template.)
$permDefs = @(
    [ordered]@{ Name = $PermOwnName; Table = $TableLogical; Scope = $scope['Global']; Rel = $null
                Read = $false; Create = $true; Write = $false; Delete = $false; Append = $false; AppendTo = $false }
)
foreach ($d in $permDefs) {
    $fields = @{
        "${P}_entitylogicalname" = $d.Table
        "${P}_scope"             = $d.Scope
        "${P}_read"              = $d.Read
        "${P}_create"            = $d.Create
        "${P}_write"             = $d.Write
        "${P}_delete"            = $d.Delete
        "${P}_append"            = $d.Append
        "${P}_appendto"          = $d.AppendTo
    }
    $fields["${P}_contactrelationship"] = $d.Rel   # $null clears a relationship left from an older setup

    $hit = @($existingPerms | Where-Object { $_.($permMeta.Name) -eq $d.Name }) | Select-Object -First 1
    $permId = $null
    if ($hit) {
        $permId = $hit.($permMeta.Id)
        if ($PSCmdlet.ShouldProcess($d.Name, 'Update table permission settings')) {
            Invoke-Dv PATCH "$($permMeta.Set)($permId)" $fields | Out-Null
            Write-Host "  '$($d.Name)' - exists, settings re-applied" -ForegroundColor Green; $updated++
        }
    } elseif ($PSCmdlet.ShouldProcess($d.Name, 'Create table permission')) {
        $body = $fields.Clone()
        $body[$permMeta.Name]           = $d.Name
        $body["$permSiteNv@odata.bind"] = "/$($siteMeta.Set)($siteId)"
        $res = Invoke-Dv POST $permMeta.Set $body
        $permId = $res.($permMeta.Id)
        if (-not $permId) {   # some environments ignore Prefer: return=representation
            $permId = (@(Get-All $permMeta "$($permMeta.Id),$($permMeta.Name),$siteKey" |
                Where-Object { $_.$siteKey -eq $siteId -and $_.($permMeta.Name) -eq $d.Name }) | Select-Object -First 1).($permMeta.Id)
        }
        Write-Host "  '$($d.Name)' - created" -ForegroundColor Green; $created++
    }

    if ($permId) {
        $linked = @((Invoke-Dv GET "$($permMeta.Set)($permId)/$roleNav`?`$select=$($roleMeta.Id)").value | ForEach-Object { $_.($roleMeta.Id) })
        if ($linked -contains $authRoleId) {
            Write-Host "    web role already assigned" -ForegroundColor DarkGray; $skipped++
        } elseif ($PSCmdlet.ShouldProcess($d.Name, 'Assign Authenticated Users web role')) {
            Invoke-Dv POST "$($permMeta.Set)($permId)/$roleNav/`$ref" @{ '@odata.id' = "$Api/$($roleMeta.Set)($authRoleId)" } | Out-Null
            # Read it back: on some Power Pages versions the link is accepted but not stored
            $check = @((Invoke-Dv GET "$($permMeta.Set)($permId)/$roleNav`?`$select=$($roleMeta.Id)").value | ForEach-Object { $_.($roleMeta.Id) })
            if ($check -contains $authRoleId) {
                Write-Host "    web role assigned" -ForegroundColor Green; $created++
            } else {
                Write-Warning "Web role could not be linked automatically to '$($d.Name)'."
                $manualRoles += $d.Name
            }
        }
    }
}

# ---------------------------------------------------------------------------
# 5. Dataverse column security profile for staff
# ---------------------------------------------------------------------------
Write-Host "Column security profile '$StaffProfileName'..." -ForegroundColor Cyan
$secured = Invoke-Dv GET "EntityDefinitions(LogicalName='$TableLogical')/Attributes?`$select=LogicalName,IsSecured"
$securedNames = @($secured.value | Where-Object { $_.IsSecured -eq $true } | ForEach-Object { $_.LogicalName })
$notSecured = @($sensitive | Where-Object { $securedNames -notcontains $_ })
if ($notSecured) { Write-Warning "These Sensitive columns don't have column security turned on, so they're visible to all staff: $($notSecured -join ', ')" }

$prof = @((Invoke-Dv GET "fieldsecurityprofiles?`$select=fieldsecurityprofileid,name&`$filter=name eq '$(Q $StaffProfileName)'").value) | Select-Object -First 1
$profId = $null
if ($prof) {
    $profId = $prof.fieldsecurityprofileid
    Write-Host "  profile exists" -ForegroundColor DarkGray; $skipped++
} elseif ($PSCmdlet.ShouldProcess($StaffProfileName, 'Create column security profile')) {
    $res = Invoke-Dv POST 'fieldsecurityprofiles' @{ name = $StaffProfileName; description = 'Staff who may see sensitive Apprentice Sign Up columns (USI, DOB, citizenship, Indigenous status, disability, guardian details).' }
    $profId = $res.fieldsecurityprofileid
    if (-not $profId) { $profId = (@((Invoke-Dv GET "fieldsecurityprofiles?`$select=fieldsecurityprofileid&`$filter=name eq '$(Q $StaffProfileName)'").value) | Select-Object -First 1).fieldsecurityprofileid }
    Write-Host "  profile created" -ForegroundColor Green; $created++
}
if ($profId) {
    $existingFp = @((Invoke-Dv GET "fieldpermissions?`$select=fieldpermissionid,attributelogicalname,canread,cancreate,canupdate&`$filter=_fieldsecurityprofileid_value eq $profId and entityname eq '$TableLogical'").value)
    foreach ($col in ($sensitive | Where-Object { $securedNames -contains $_ })) {
        $fp = @($existingFp | Where-Object { $_.attributelogicalname -eq $col }) | Select-Object -First 1
        $perm = @{ canread = 4; cancreate = 4; canupdate = 4 }    # 4 = Allowed
        if ($fp) {
            if ($fp.canread -eq 4 -and $fp.cancreate -eq 4 -and $fp.canupdate -eq 4) { $skipped++; continue }
            if ($PSCmdlet.ShouldProcess($col, 'Allow read/create/update in profile')) {
                Invoke-Dv PATCH "fieldpermissions($($fp.fieldpermissionid))" $perm | Out-Null; $updated++
            }
        } elseif ($PSCmdlet.ShouldProcess($col, 'Add to column security profile')) {
            $body = $perm.Clone()
            $body.entityname          = $TableLogical
            $body.attributelogicalname = $col
            $body['fieldsecurityprofileid@odata.bind'] = "/fieldsecurityprofiles($profId)"
            Invoke-Dv POST 'fieldpermissions' $body | Out-Null; $created++
        }
    }
    Write-Host "  $(@($sensitive | Where-Object { $securedNames -contains $_ }).Count) sensitive columns covered" -ForegroundColor Green
}

# ---------------------------------------------------------------------------
# 6. Optional: staff security role
# ---------------------------------------------------------------------------
if ($StaffRoleName) {
    Write-Host "Security role '$StaffRoleName'..." -ForegroundColor Cyan
    $role = @((Invoke-Dv GET "roles?`$select=roleid,name&`$filter=name eq '$(Q $StaffRoleName)' and _parentroleid_value eq null").value) | Select-Object -First 1
    if (-not $role) { throw "Security role '$StaffRoleName' not found. Create it (or copy an existing one) in the admin centre first, or leave out -StaffRoleName." }
    $privNames = @('Create', 'Read', 'Write', 'Append', 'AppendTo', 'Assign') | ForEach-Object { "prv$_$TableLogical" }
    $filter = ($privNames | ForEach-Object { "name eq '$_'" }) -join ' or '
    $privs = @((Invoke-Dv GET "privileges?`$select=privilegeid,name&`$filter=$filter").value)
    if ($privs.Count -ne $privNames.Count) { throw "Expected $($privNames.Count) privileges for $TableLogical, found $($privs.Count)." }
    if ($PSCmdlet.ShouldProcess($StaffRoleName, "Grant Organisation-level Create/Read/Write/Append/AppendTo/Assign on $TableLogical")) {
        Invoke-Dv POST "roles($($role.roleid))/Microsoft.Dynamics.CRM.AddPrivilegesRole" @{
            Privileges = @($privs | ForEach-Object { @{ PrivilegeId = $_.privilegeid; Depth = 'Global' } })
        } | Out-Null
        Write-Host "  privileges granted" -ForegroundColor Green; $updated++
    }
}

# ---------------------------------------------------------------------------
# Summary + remaining manual steps
# ---------------------------------------------------------------------------
Write-Host ""
if ($WhatIfPreference) {
    Write-Host "No changes made (-WhatIf). All checks passed." -ForegroundColor Green
} else {
    Write-Host "Done. Created $created, updated $updated, already in place $skipped." -ForegroundColor Green
}
Write-Host ""
if ($manualRoles) {
    Write-Host "ACTION NEEDED - assign the web role by hand (otherwise submissions fail with 'You don't have permission'):" -ForegroundColor Red
    Write-Host "  Studio > Security > Table permissions > open each of these > Roles > + Add roles > Authenticated Users > Save:" -ForegroundColor Red
    $manualRoles | ForEach-Object { Write-Host "    - $_" -ForegroundColor Red }
    Write-Host ""
}
Write-Host "Still to do by hand:" -ForegroundColor Cyan
Write-Host "  1. Power Pages Studio > Sync (top right), so the site picks up these settings."
Write-Host "  2. Add staff to the column security profile:"
Write-Host "       admin centre > environment > Settings > Users + permissions > Column security profiles > '$StaffProfileName' > Users/Teams"
if (-not $StaffRoleName) {
    Write-Host "  3. Give your staff security role Organisation-level access to Apprentice Sign Up"
    Write-Host "       (or re-run with -StaffRoleName `"<role name>`")."
}
Write-Host "  4. Power Pages Studio > Security > Column permissions > New: table Apprentice Sign Up,"
Write-Host "     Create on these columns, web role Authenticated Users:"
Write-Host "       $($securedNames -join ', ')"
Write-Host "  5. Restrict the Sign-Up page to Authenticated Users (Studio > Pages > page > Permissions)."
