<#
.SYNOPSIS
    Sets up the tracking-code check so the sign-up form can run WITHOUT sign-in
    (anonymous Power Pages licence), accepting only codes ASA has issued.

.DESCRIPTION
    Run AFTER Create-ApprenticeSignUpTable.ps1 and Configure-ApprenticeSignUpSecurity.ps1.

    Dataverse
      1. New table <prefix>_signupinvite ("Sign Up Invite") - one row per issued code:
           Sign Up Tracking Code (primary, unique key, GENERATED AUTOMATICALLY on create,
           e.g. ASA-10001-K7Q2ZP - change with -CodeFormat), Applicant Name, Invite Status (Issued=1, Used=2,
           Cancelled=3, default Issued), Expires On (optional), Email Sent To, Used On
      2. On Apprentice Sign Up: Verification Status (Pending=1, Verified=2, Invalid code=3,
           Code already used=4, Code expired=5, default Pending) and a Sign Up Invite lookup
           - both set by the Power Automate flow, never by the website
    Power Pages
      3. Table permission "Sign Up Invite - code check": Global, Read only, for Anonymous
         and Authenticated Users (lets the page's server-side check look a code up)
      4. Adds Anonymous Users to the Apprentice Sign Up create permission
      5. Warns if the Web API is enabled for the invite table (it must not be)

    Still manual afterwards (printed at the end, detailed in TRACKING-CODE-CHECK.md):
      - remove the page permission so the Sign-Up page is open
      - paste the updated web template, Sync
      - build the verification flow in Power Automate
      - load your issued codes into Sign Up Invites

    Safe to re-run. Modes: -PlanOnly (no connection), -WhatIf (connects, changes nothing).

.EXAMPLE
    .\Enable-TrackingCodeCheck.ps1 -EnvironmentUrl https://yourorg-dev.crm6.dynamics.com `
        -SolutionUniqueName ASATestAIApp -Prefix bnsw -WebsiteName "ASA Sign Up" -WhatIf
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string] $EnvironmentUrl,
    [string] $SolutionUniqueName,
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[A-Za-z][A-Za-z0-9]{1,7}$')]
    [string] $Prefix,
    [string] $WebsiteName,
    [string] $TenantId,
    [string] $AccessToken,
    [switch] $Relogin,
    [int]    $LanguageCode = 1033,
    [string] $CodeFormat = 'ASA-{SEQNUM:5}-{RANDSTRING:6}',
    [switch] $PlanOnly
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$Prefix       = $Prefix.ToLowerInvariant()
$AppTable     = "${Prefix}_apprenticesignup"
$InvTable     = "${Prefix}_signupinvite"
$InvSchema    = "${Prefix}_SignUpInvite"
$InvLookup    = "${Prefix}_Invite"                     # lookup on Apprentice Sign Up (schema name)
$InvRel       = "${Prefix}_signupinvite_${Prefix}_apprenticesignup"
$PermAppName  = 'Apprentice Sign Up - own records'      # created by Configure-ApprenticeSignUpSecurity.ps1
$PermInvName  = 'Sign Up Invite - code check'

$InviteStatus = @(@('Issued', 1), @('Used', 2), @('Cancelled', 3))
$VerifyStatus = @(@('Pending', 1), @('Verified', 2), @('Invalid code', 3), @('Code already used', 4), @('Code expired', 5))

if ($PlanOnly) {
    Write-Host "PLAN ONLY - nothing will be changed.`n" -ForegroundColor Cyan
    Write-Host "Dataverse:"
    Write-Host "  Table $InvTable 'Sign Up Invite' (primary ${Prefix}_trackingcode, unique key,"
    Write-Host "    codes generated automatically: $CodeFormat  e.g. ASA-10001-K7Q2ZP)"
    Write-Host "    ${Prefix}_applicantname Text"
    Write-Host "    ${Prefix}_invitestatus  Choice  $(($InviteStatus | ForEach-Object { "$($_[0])=$($_[1])" }) -join ', ') (default Issued)"
    Write-Host "    ${Prefix}_expireson     Date only"
    Write-Host "    ${Prefix}_inviteemail   Email"
    Write-Host "    ${Prefix}_usedon        Date and time"
    Write-Host "  On ${AppTable}:"
    Write-Host "    ${Prefix}_verificationstatus  Choice  $(($VerifyStatus | ForEach-Object { "$($_[0])=$($_[1])" }) -join ', ') (default Pending)"
    Write-Host "    ${Prefix}_invite              Lookup -> $InvTable  (navigation property $InvLookup)"
    Write-Host "Power Pages:"
    Write-Host "  '$PermInvName': $InvTable, Global, Read only, Anonymous + Authenticated Users"
    Write-Host "  '$PermAppName': add Anonymous Users"
    return
}

if (-not $EnvironmentUrl -or -not $SolutionUniqueName) { throw "-EnvironmentUrl and -SolutionUniqueName are required (or use -PlanOnly)." }
$EnvironmentUrl = $EnvironmentUrl.TrimEnd('/')
$Api = "$EnvironmentUrl/api/data/v9.2"

# ---------------------------------------------------------------------------
# Authentication (same as the other scripts)
# ---------------------------------------------------------------------------
if (-not $AccessToken) {
    if (-not (Get-Module -ListAvailable -Name Az.Accounts)) {
        throw "Az.Accounts module not found. Run:  Install-Module Az.Accounts -Scope CurrentUser   (or pass -AccessToken)."
    }
    Import-Module Az.Accounts -ErrorAction Stop

    # Sign-in commands must really run even when the script runs with -WhatIf,
    # so pass -WhatIf:$false to every command that supports it.
    function Get-NoWhatIf([string] $name, [hashtable] $a) {
        if ((Get-Command $name).Parameters.ContainsKey('WhatIf')) { $a.WhatIf = $false }
        $a
    }
    function Connect-AzLogin {
        Write-Host "Signing in$(if ($TenantId) { " to $TenantId" })..." -ForegroundColor Cyan
        $connectArgs = Get-NoWhatIf 'Connect-AzAccount' @{ ErrorAction = 'Stop' }
        if ($TenantId) { $connectArgs.TenantId = $TenantId }
        Connect-AzAccount @connectArgs | Out-Null
    }
    function Clear-AzLogin {
        $d = Get-NoWhatIf 'Disconnect-AzAccount' @{ ErrorAction = 'SilentlyContinue' }
        Disconnect-AzAccount @d | Out-Null
        $c = Get-NoWhatIf 'Clear-AzContext' @{ Force = $true; ErrorAction = 'SilentlyContinue' }
        Clear-AzContext @c | Out-Null
    }

    if ($Relogin) {
        Write-Host "Clearing the previous sign-in (-Relogin)..." -ForegroundColor Cyan
        Clear-AzLogin
    }
    if (-not (Get-AzContext -ErrorAction SilentlyContinue)) { Connect-AzLogin }

    $tok = $null
    try {
        $tok = Get-AzAccessToken -ResourceUrl $EnvironmentUrl -ErrorAction Stop
    } catch {
        Write-Warning "The saved sign-in didn't work ($($_.Exception.Message)). Signing in again..."
        Clear-AzLogin
        Connect-AzLogin
        try {
            $tok = Get-AzAccessToken -ResourceUrl $EnvironmentUrl -ErrorAction Stop
        } catch {
            throw "Could not get a token for $EnvironmentUrl after signing in again: $($_.Exception.Message)`nCheck you signed in with your work account, try adding -TenantId businessnsw.com, and check your account has a security role in this environment. Or pass -AccessToken."
        }
    }
    if ($tok.Token -is [System.Security.SecureString]) {
        $AccessToken = [System.Net.NetworkCredential]::new('', $tok.Token).Password
    } else {
        $AccessToken = $tok.Token
    }
}

function Invoke-Dv {
    param([string] $Method, [string] $Path, $Body, [switch] $AllowNotFound, [hashtable] $ExtraHeaders)
    $headers = @{
        Authorization      = "Bearer $AccessToken"
        Accept             = 'application/json'
        'OData-MaxVersion' = '4.0'
        'OData-Version'    = '4.0'
        'MSCRM.SolutionUniqueName' = $SolutionUniqueName
        Prefer             = 'return=representation'
    }
    if ($ExtraHeaders) { foreach ($k in $ExtraHeaders.Keys) { $headers[$k] = $ExtraHeaders[$k] } }
    $req = @{ Method = $Method; Uri = "$Api/$Path"; Headers = $headers }
    if ($null -ne $Body) {
        $json = $Body | ConvertTo-Json -Depth 30 -Compress
        $req.Body        = [System.Text.Encoding]::UTF8.GetBytes($json)
        $req.ContentType = 'application/json; charset=utf-8'
    }
    for ($attempt = 1; ; $attempt++) {
        try {
            return Invoke-RestMethod @req
        } catch {
            $status = 0
            $respProp = $_.Exception.PSObject.Properties['Response']
            if ($respProp -and $respProp.Value) { $status = [int]$respProp.Value.StatusCode }
            if ($status -eq 404 -and $AllowNotFound) { return $null }
            $detail = if ($_.ErrorDetails) { $_.ErrorDetails.Message } else { $null }
            if (-not $detail) { $detail = $_.Exception.Message }
            $retryable = $status -eq 429 -or $status -ge 500 -or $detail -match 'another.*(customization|publish).*running|0x80071151'
            if ($retryable -and $attempt -lt 6) {
                $wait = [math]::Min(60, [math]::Pow(2, $attempt) * 2)
                Write-Warning "  $Method $Path returned $status - retrying in $wait s ($attempt/5)"
                Start-Sleep -Seconds $wait
                continue
            }
            throw "Dataverse $Method $Path failed ($status): $detail"
        }
    }
}

function New-Label([string] $Text) {
    @{ '@odata.type' = 'Microsoft.Dynamics.CRM.Label'
       LocalizedLabels = @(@{ '@odata.type' = 'Microsoft.Dynamics.CRM.LocalizedLabel'; Label = $Text; LanguageCode = $LanguageCode }) }
}
function New-Req([bool] $r) { @{ Value = $(if ($r) { 'ApplicationRequired' } else { 'None' }); CanBeChanged = $true; ManagedPropertyLogicalName = 'canmodifyrequirementlevelsettings' } }
function New-Picklist([string] $schema, [string] $label, [string] $desc, $options, [bool] $required) {
    @{ '@odata.type' = 'Microsoft.Dynamics.CRM.PicklistAttributeMetadata'
       SchemaName = $schema; DisplayName = New-Label $label; Description = New-Label $desc; RequiredLevel = New-Req $required
       DefaultFormValue = $options[0][1]
       OptionSet = @{ '@odata.type' = 'Microsoft.Dynamics.CRM.OptionSetMetadata'; IsGlobal = $false; OptionSetType = 'Picklist'
                      Options = @($options | ForEach-Object { @{ Value = $_[1]; Label = New-Label $_[0] } }) } }
}
function Get-AttrNames([string] $table) {
    @((Invoke-Dv GET "EntityDefinitions(LogicalName='$table')/Attributes?`$select=LogicalName").value | ForEach-Object { $_.LogicalName })
}
function Q([string] $s) { $s.Replace("'", "''") }

$created = 0; $skipped = 0; $manual = @()

# ---------------------------------------------------------------------------
# 0. Solution + prefix, apprentice table
# ---------------------------------------------------------------------------
Write-Host "Checking solution '$SolutionUniqueName'..." -ForegroundColor Cyan
$sol = Invoke-Dv GET ("solutions?`$select=uniquename,ismanaged&`$filter=uniquename eq '$(Q $SolutionUniqueName)'&`$expand=publisherid(`$select=customizationprefix)")
if (-not $sol.value -or $sol.value.Count -eq 0) { throw "Solution '$SolutionUniqueName' not found (use its Name / unique name)." }
if ($sol.value[0].publisherid.customizationprefix -ne $Prefix) { throw "Solution publisher prefix is '$($sol.value[0].publisherid.customizationprefix)', not '$Prefix'." }
if (-not (Invoke-Dv GET "EntityDefinitions(LogicalName='$AppTable')?`$select=LogicalName" -AllowNotFound)) {
    throw "Table $AppTable not found - run Create-ApprenticeSignUpTable.ps1 first."
}

# ---------------------------------------------------------------------------
# 1. Sign Up Invite table
# ---------------------------------------------------------------------------
Write-Host "Sign Up Invite table..." -ForegroundColor Cyan
$invPath = "EntityDefinitions(LogicalName='$InvTable')"
$invNew = $false
if (Invoke-Dv GET "$invPath`?`$select=LogicalName" -AllowNotFound) {
    Write-Host "  $InvTable exists" -ForegroundColor DarkGray; $skipped++
} elseif ($PSCmdlet.ShouldProcess($InvTable, 'Create table')) {
    Invoke-Dv POST 'EntityDefinitions' @{
        '@odata.type' = 'Microsoft.Dynamics.CRM.EntityMetadata'
        SchemaName = $InvSchema
        DisplayName = New-Label 'Sign Up Invite'; DisplayCollectionName = New-Label 'Sign Up Invites'
        Description = New-Label 'Tracking codes ASA has issued. The sign-up form only accepts codes listed here with status Issued.'
        OwnershipType = 'UserOwned'; IsActivity = $false; HasActivities = $false; HasNotes = $false
        Attributes = @(@{
            '@odata.type' = 'Microsoft.Dynamics.CRM.StringAttributeMetadata'
            SchemaName = "${Prefix}_trackingcode"; IsPrimaryName = $true; MaxLength = 100; FormatName = @{ Value = 'Text' }
            AutoNumberFormat = $CodeFormat
            DisplayName = New-Label 'Sign Up Tracking Code'; Description = New-Label 'Generated automatically when the invite is created. Sent to the applicant in their sign-up link.'
            RequiredLevel = New-Req $false
        })
    } | Out-Null
    Write-Host "  created $InvTable" -ForegroundColor Green; $created++; $invNew = $true
}

$invAttrs = if ($invNew -or (Invoke-Dv GET "$invPath`?`$select=LogicalName" -AllowNotFound)) { Get-AttrNames $InvTable } else { @() }
# Existing table (e.g. created by an earlier version of this script): switch the code column to autonumber
if (-not $invNew -and $invAttrs -contains "${Prefix}_trackingcode") {
    $codeAttrPath = "$invPath/Attributes(LogicalName='${Prefix}_trackingcode')"
    $codeAttr = Invoke-Dv GET "$codeAttrPath/Microsoft.Dynamics.CRM.StringAttributeMetadata"
    $current = $codeAttr.PSObject.Properties['AutoNumberFormat']
    if ($current -and $current.Value -eq $CodeFormat) {
        Write-Host "  codes already generated automatically ($CodeFormat)" -ForegroundColor DarkGray; $skipped++
    } elseif ($PSCmdlet.ShouldProcess("${Prefix}_trackingcode", "Generate codes automatically ($CodeFormat)")) {
        $upd = [ordered]@{ '@odata.type' = 'Microsoft.Dynamics.CRM.StringAttributeMetadata' }
        foreach ($prop in $codeAttr.PSObject.Properties) { if ($prop.Name -notlike '@odata.*') { $upd[$prop.Name] = $prop.Value } }
        $upd['AutoNumberFormat'] = $CodeFormat
        $upd['RequiredLevel'] = New-Req $false
        Invoke-Dv PUT $codeAttrPath $upd -ExtraHeaders @{ 'MSCRM.MergeLabels' = 'true' } | Out-Null
        Write-Host "  codes now generated automatically ($CodeFormat)" -ForegroundColor Green; $created++
    }
}

$invCols = @(
    @{ '@odata.type' = 'Microsoft.Dynamics.CRM.StringAttributeMetadata'; SchemaName = "${Prefix}_applicantname"; MaxLength = 200; FormatName = @{ Value = 'Text' }
       DisplayName = New-Label 'Applicant Name'; Description = New-Label 'Optional. Who the sign-up link is for (used in the invitation email).'; RequiredLevel = New-Req $false },
    (New-Picklist "${Prefix}_invitestatus" 'Invite Status' 'Issued = can be used; Used = a sign-up was received (set by the flow); Cancelled = blocked.' $InviteStatus $true),
    @{ '@odata.type' = 'Microsoft.Dynamics.CRM.DateTimeAttributeMetadata'; SchemaName = "${Prefix}_expireson"; Format = 'DateOnly'; DateTimeBehavior = @{ Value = 'DateOnly' }
       DisplayName = New-Label 'Expires On'; Description = New-Label 'Optional. The link stops working after this date.'; RequiredLevel = New-Req $false },
    @{ '@odata.type' = 'Microsoft.Dynamics.CRM.StringAttributeMetadata'; SchemaName = "${Prefix}_inviteemail"; MaxLength = 100; FormatName = @{ Value = 'Email' }
       DisplayName = New-Label 'Email Sent To'; Description = New-Label 'Optional. Where the sign-up link was emailed.'; RequiredLevel = New-Req $false },
    @{ '@odata.type' = 'Microsoft.Dynamics.CRM.DateTimeAttributeMetadata'; SchemaName = "${Prefix}_usedon"; Format = 'DateAndTime'; DateTimeBehavior = @{ Value = 'UserLocal' }
       DisplayName = New-Label 'Used On'; Description = New-Label 'Set by the flow when a sign-up with this code is received.'; RequiredLevel = New-Req $false }
)
foreach ($c in $invCols) {
    if ($invAttrs -contains $c.SchemaName) { Write-Host "  $($c.SchemaName) exists" -ForegroundColor DarkGray; $skipped++; continue }
    if ($PSCmdlet.ShouldProcess("$InvTable.$($c.SchemaName)", 'Create column')) {
        Invoke-Dv POST "$invPath/Attributes" $c | Out-Null
        Write-Host "  created $($c.SchemaName)" -ForegroundColor Green; $created++
    }
}

# Unique key on the tracking code (no duplicate codes)
if ($invNew -or $invAttrs) {
    $keys = @((Invoke-Dv GET "$invPath/Keys?`$select=SchemaName,KeyAttributes").value)
    if (@($keys | Where-Object { @($_.KeyAttributes) -contains "${Prefix}_trackingcode" }).Count -gt 0) {
        Write-Host "  unique key on tracking code exists" -ForegroundColor DarkGray; $skipped++
    } elseif ($PSCmdlet.ShouldProcess($InvTable, 'Create unique key on tracking code')) {
        Invoke-Dv POST "$invPath/Keys" @{ SchemaName = "${Prefix}_TrackingCodeKey"; DisplayName = New-Label 'Tracking Code'; KeyAttributes = @("${Prefix}_trackingcode") } | Out-Null
        Write-Host "  created unique key on tracking code (Dataverse activates it in the background)" -ForegroundColor Green; $created++
    }
}

# ---------------------------------------------------------------------------
# 2. Apprentice Sign Up: Verification Status + Invite lookup
# ---------------------------------------------------------------------------
Write-Host "Apprentice Sign Up additions..." -ForegroundColor Cyan
$appPath = "EntityDefinitions(LogicalName='$AppTable')"
$appAttrs = Get-AttrNames $AppTable
if ($appAttrs -contains "${Prefix}_verificationstatus") { Write-Host "  ${Prefix}_verificationstatus exists" -ForegroundColor DarkGray; $skipped++ }
elseif ($PSCmdlet.ShouldProcess("$AppTable.${Prefix}_verificationstatus", 'Create column')) {
    Invoke-Dv POST "$appPath/Attributes" (New-Picklist "${Prefix}_verificationstatus" 'Verification Status' 'Set by the verification flow from the tracking code. Pending = not checked yet.' $VerifyStatus $false) | Out-Null
    Write-Host "  created ${Prefix}_verificationstatus" -ForegroundColor Green; $created++
}
if ($appAttrs -contains "${Prefix}_invite") { Write-Host "  ${Prefix}_invite exists" -ForegroundColor DarkGray; $skipped++ }
elseif ($invAttrs -or $invNew) {
    if ($PSCmdlet.ShouldProcess("$AppTable.${Prefix}_invite", 'Create lookup to Sign Up Invite')) {
        Invoke-Dv POST 'RelationshipDefinitions' @{
            '@odata.type' = 'Microsoft.Dynamics.CRM.OneToManyRelationshipMetadata'
            SchemaName = $InvRel; ReferencedEntity = $InvTable; ReferencingEntity = $AppTable
            CascadeConfiguration = @{ Assign = 'NoCascade'; Delete = 'RemoveLink'; Merge = 'Cascade'; Reparent = 'NoCascade'; Share = 'NoCascade'; Unshare = 'NoCascade'; RollupView = 'NoCascade' }
            Lookup = @{ '@odata.type' = 'Microsoft.Dynamics.CRM.LookupAttributeMetadata'; SchemaName = $InvLookup
                        DisplayName = New-Label 'Sign Up Invite'; Description = New-Label 'The invite (tracking code) this sign-up used. Set by the verification flow.'; RequiredLevel = New-Req $false }
        } | Out-Null
        Write-Host "  created lookup ${Prefix}_invite" -ForegroundColor Green; $created++
    }
}

if (-not $WhatIfPreference -and $created -gt 0) {
    Write-Host "Publishing..." -ForegroundColor Cyan
    Invoke-Dv POST 'PublishXml' @{ ParameterXml = "<importexportxml><entities><entity>$InvTable</entity><entity>$AppTable</entity></entities></importexportxml>" } | Out-Null
}

# ---------------------------------------------------------------------------
# 3. Power Pages permissions
# ---------------------------------------------------------------------------
function Get-TableMeta([string] $logical) {
    $e = Invoke-Dv GET "EntityDefinitions(LogicalName='$logical')?`$select=LogicalName,EntitySetName,PrimaryIdAttribute,PrimaryNameAttribute" -AllowNotFound
    if (-not $e) { return $null }
    $a   = Invoke-Dv GET "EntityDefinitions(LogicalName='$logical')/Attributes?`$select=LogicalName"
    $m2o = Invoke-Dv GET "EntityDefinitions(LogicalName='$logical')/ManyToOneRelationships?`$select=ReferencingAttribute,ReferencingEntityNavigationPropertyName"
    [pscustomobject]@{ Logical = $logical; Set = $e.EntitySetName; Id = $e.PrimaryIdAttribute; Name = $e.PrimaryNameAttribute
                       Attrs = @($a.value | ForEach-Object { $_.LogicalName }); M2O = @($m2o.value) }
}
function Get-All($meta, [string] $select) { @((Invoke-Dv GET "$($meta.Set)?`$select=$select").value) }
function Get-Prop($obj, [string] $name) { $p = $obj.PSObject.Properties[$name]; if ($p) { $p.Value } else { $null } }

Write-Host "Finding the Power Pages site..." -ForegroundColor Cyan
$P = $null; $siteMeta = $null; $site = $null
foreach ($candidate in @('mspp', 'adx')) {
    $m = Get-TableMeta "${candidate}_website"
    if (-not $m) { continue }
    $sites = Get-All $m "$($m.Id),$($m.Name)"
    if ($WebsiteName) { $sites = @($sites | Where-Object { $_.($m.Name) -eq $WebsiteName }) }
    if ($sites.Count -eq 1) { $P = $candidate; $siteMeta = $m; $site = $sites[0]; break }
    if ($sites.Count -gt 1) { throw "More than one site found ($(($sites | ForEach-Object { "'" + $_.($m.Name) + "'" }) -join ', ')). Use -WebsiteName." }
}
if (-not $site) { throw "No Power Pages site$(if ($WebsiteName) { " named '$WebsiteName'" }) found." }
$siteId = $site.($siteMeta.Id); $siteKey = "_${P}_websiteid_value"
Write-Host "  OK - '$($site.($siteMeta.Name))'"

$permMeta    = Get-TableMeta "${P}_entitypermission"
$roleMeta    = Get-TableMeta "${P}_webrole"
$settingMeta = Get-TableMeta "${P}_sitesetting"
foreach ($need in @("${P}_anonymoususersrole", "${P}_authenticatedusersrole")) {
    if ($roleMeta.Attrs -notcontains $need) { throw "Web role table has no $need column - unexpected Power Pages version. Nothing changed on the site." }
}
$permSiteNv = ($permMeta.M2O | Where-Object { $_.ReferencingAttribute -eq "${P}_websiteid" } | Select-Object -First 1).ReferencingEntityNavigationPropertyName
$m2m = Invoke-Dv GET "EntityDefinitions(LogicalName='${P}_entitypermission')/ManyToManyRelationships?`$select=Entity1LogicalName,Entity2LogicalName,Entity1NavigationPropertyName,Entity2NavigationPropertyName"
$rr = @($m2m.value | Where-Object { ($_.Entity1LogicalName -eq "${P}_entitypermission" -and $_.Entity2LogicalName -eq "${P}_webrole") -or ($_.Entity2LogicalName -eq "${P}_entitypermission" -and $_.Entity1LogicalName -eq "${P}_webrole") }) | Select-Object -First 1
$roleNav = if ($rr.Entity1LogicalName -eq "${P}_entitypermission") { $rr.Entity1NavigationPropertyName } else { $rr.Entity2NavigationPropertyName }

$scopeAttr = Invoke-Dv GET "EntityDefinitions(LogicalName='${P}_entitypermission')/Attributes(LogicalName='${P}_scope')/Microsoft.Dynamics.CRM.PicklistAttributeMetadata?`$select=LogicalName&`$expand=OptionSet(`$select=Options)"
$globalScope = ($scopeAttr.OptionSet.Options | Where-Object { $_.Label.UserLocalizedLabel.Label -eq 'Global' } | Select-Object -First 1).Value
if ($null -eq $globalScope) { throw "Scope 'Global' not found on table permissions." }

$roles = @(Get-All $roleMeta "$($roleMeta.Id),$($roleMeta.Name),${P}_anonymoususersrole,${P}_authenticatedusersrole,$siteKey" | Where-Object { (Get-Prop $_ $siteKey) -eq $siteId })
$anonRole = @($roles | Where-Object { (Get-Prop $_ "${P}_anonymoususersrole") -eq $true }) | Select-Object -First 1
$authRole = @($roles | Where-Object { (Get-Prop $_ "${P}_authenticatedusersrole") -eq $true }) | Select-Object -First 1
if (-not $anonRole) { throw "No 'Anonymous Users' web role found for this site." }
$anonId = $anonRole.($roleMeta.Id); $authId = if ($authRole) { $authRole.($roleMeta.Id) } else { $null }

function Add-Role([string] $permId, [string] $permName, [string] $roleId, [string] $roleLabel) {
    $linked = @((Invoke-Dv GET "$($permMeta.Set)($permId)/$roleNav`?`$select=$($roleMeta.Id)").value | ForEach-Object { $_.($roleMeta.Id) })
    if ($linked -contains $roleId) { Write-Host "    $roleLabel already assigned" -ForegroundColor DarkGray; $script:skipped++; return }
    if (-not $PSCmdlet.ShouldProcess($permName, "Assign $roleLabel")) { return }
    Invoke-Dv POST "$($permMeta.Set)($permId)/$roleNav/`$ref" @{ '@odata.id' = "$Api/$($roleMeta.Set)($roleId)" } | Out-Null
    $check = @((Invoke-Dv GET "$($permMeta.Set)($permId)/$roleNav`?`$select=$($roleMeta.Id)").value | ForEach-Object { $_.($roleMeta.Id) })
    if ($check -contains $roleId) { Write-Host "    $roleLabel assigned" -ForegroundColor Green; $script:created++ }
    else { Write-Warning "$roleLabel could not be linked automatically to '$permName'."; $script:manual += "'$permName': Roles > + Add roles > $roleLabel" }
}

Write-Host "Table permissions..." -ForegroundColor Cyan
$perms = @(Get-All $permMeta "$($permMeta.Id),$($permMeta.Name),${P}_entitylogicalname,$siteKey" | Where-Object { (Get-Prop $_ $siteKey) -eq $siteId })

# 3a. Invite: Global, Read only
$inv = @($perms | Where-Object { $_.($permMeta.Name) -eq $PermInvName }) | Select-Object -First 1
$invPermId = if ($inv) { $inv.($permMeta.Id) } else { $null }
$invFields = @{ "${P}_entitylogicalname" = $InvTable; "${P}_scope" = $globalScope
                "${P}_read" = $true; "${P}_create" = $false; "${P}_write" = $false; "${P}_delete" = $false; "${P}_append" = $false; "${P}_appendto" = $false }
if ($inv) {
    if ($PSCmdlet.ShouldProcess($PermInvName, 'Re-apply settings')) { Invoke-Dv PATCH "$($permMeta.Set)($invPermId)" $invFields | Out-Null }
    Write-Host "  '$PermInvName' exists" -ForegroundColor DarkGray; $skipped++
} elseif ($PSCmdlet.ShouldProcess($PermInvName, 'Create table permission')) {
    $body = $invFields.Clone(); $body[$permMeta.Name] = $PermInvName; $body["$permSiteNv@odata.bind"] = "/$($siteMeta.Set)($siteId)"
    $res = Invoke-Dv POST $permMeta.Set $body
    $invPermId = $res.($permMeta.Id)
    if (-not $invPermId) { $invPermId = (@(Get-All $permMeta "$($permMeta.Id),$($permMeta.Name),$siteKey" | Where-Object { $_.$siteKey -eq $siteId -and $_.($permMeta.Name) -eq $PermInvName }) | Select-Object -First 1).($permMeta.Id) }
    Write-Host "  '$PermInvName' created" -ForegroundColor Green; $created++
}
if ($invPermId) {
    Add-Role $invPermId $PermInvName $anonId 'Anonymous Users'
    if ($authId) { Add-Role $invPermId $PermInvName $authId 'Authenticated Users' }
}

# 3b. Apprentice: add Anonymous Users to the create permission
$app = @($perms | Where-Object { $_.($permMeta.Name) -eq $PermAppName }) | Select-Object -First 1
if (-not $app) { $app = @($perms | Where-Object { (Get-Prop $_ "${P}_entitylogicalname") -eq $AppTable }) | Select-Object -First 1 }
if (-not $app) {
    Write-Warning "No table permission for $AppTable found - run Configure-ApprenticeSignUpSecurity.ps1 first."
    $manual += "Create the Apprentice Sign Up table permission (Global, Create only) and give it Anonymous Users"
} else {
    Write-Host "  '$($app.($permMeta.Name))'"
    Add-Role $app.($permMeta.Id) $app.($permMeta.Name) $anonId 'Anonymous Users'
}

# 3c. The invite table must NOT be exposed through the Web API
$apiOn = @(Get-All $settingMeta "$($settingMeta.Name),${P}_value,$siteKey" |
           Where-Object { (Get-Prop $_ $siteKey) -eq $siteId -and (Get-Prop $_ $settingMeta.Name) -eq "Webapi/$InvTable/enabled" -and "$(Get-Prop $_ "${P}_value")" -eq 'true' })
if ($apiOn) {
    Write-Warning "Site setting Webapi/$InvTable/enabled is true - anyone could list your codes. Delete it or set it to false."
    $manual += "Delete the site setting Webapi/$InvTable/enabled"
}

# ---------------------------------------------------------------------------
Write-Host ""
if ($WhatIfPreference) { Write-Host "No changes made (-WhatIf). Checks passed." -ForegroundColor Green }
else { Write-Host "Done. Created $created, already in place $skipped." -ForegroundColor Green }
Write-Host ""
if ($manual) {
    Write-Host "ACTION NEEDED:" -ForegroundColor Red
    $manual | ForEach-Object { Write-Host "  - $_" -ForegroundColor Red }
    Write-Host ""
}
Write-Host "Next (see TRACKING-CODE-CHECK.md):" -ForegroundColor Cyan
Write-Host "  1. Studio > Pages > Sign Up > Permissions: remove the Authenticated Users restriction (page open to everyone)."
Write-Host "  2. Paste the updated web template, then Sync."
Write-Host "  3. Build the verification flow in Power Automate."
Write-Host "  4. Add your issued codes to Sign Up Invites (e.g. Import from Excel), then test."
