# Polishing the site: branded pages without the generic header

The sign-up form and a new Home page use a standalone ASA design, with no
"Company name" header, Home / Search / Sign in links or default footer. Both pages
carry their own banner, the help line and a small footer.

Time: about 20 minutes, in the **Power Pages Management** app plus Studio.

## 1. Update the sign-up web template
**Web Templates → Apprentice Sign Up → Source:** replace everything with the new
`apprentice-signup.webtemplate.bnsw.liquid`, then click **Save**.

What changed in the form:
- **With a valid code, the "Sign Up Tracking Code" step is skipped.** The code shows in
  the banner, and the form starts at USI (12 sections instead of 13).
- **Fixed a layout bug** where checkboxes stretched across the box and radio dots
  showed as ovals.
- **Tidier on phones:** the banner stacks.
- **New footer** with the help line and an optional privacy-policy link.
- **The "link not found / used / expired" messages** now use the same branded design.

## 2. Create the Home page template
1. **Web Templates → + New**
   - Name: `ASA Home`. Website: ASA Sign Up.
   - Source: paste all of `asa-home.webtemplate.liquid`. Click **Save**.
2. **Page Templates → + New**
   - Name: `ASA Home`. Website: ASA Sign Up.
   - Type: **Web Template**. Web Template: **ASA Home**.
   - **Untick "Use Website Header and Footer".** Click **Save**.

## 3. Turn off the generic header on the sign-up page
**Page Templates → Apprentice Sign Up:** **untick "Use Website Header and Footer"**,
then click **Save**.

## 4. Point the Home page at the new template
1. **Web Pages:** you may see two rows called **Home**. Open the one whose **Partial URL**
   is `/`. If there are two with `/`, use the one with no *Root Webpage* value, i.e. the
   root page.
2. Set **Page Template** to **ASA Home**, then click **Save**.

## 5. Sync and check
Click **Sync** in Studio, then in a fresh private window check:

| Address | Expect |
|---|---|
| `https://site-9diru.powerappsportals.com/` | The branded "Apprentice & Trainee Sign Up" page, with no grey header |
| `…/?trackingcode=<a valid code>` | Goes straight to the form with that code |
| `…/sign-up/?trackingcode=<a valid code>` | The form, starting at USI, with the code in the banner |
| `…/sign-up/?trackingcode=NOTREAL` | The branded "We couldn't find this sign-up link" message |

## ASA website look and feel (latest template)
The sign-up page now matches apprenticeshipsupport.com.au:
- **Header:** the ASA logo on the left (built into the template from the brand SVG) and
  a teal **1300 363 831** call button on the right.
- **Hero:** an uppercase charcoal heading with the yellow underline bar, and the logo's
  triangle mark in the corner.
- **Colours from the logo:** teal `#279989`, dark teal `#005E5D`, cyan `#2DCCD3`,
  orange `#F68D2E`, yellow `#FFB81C`, charcoal `#414042`.
- **Buttons:** yellow **Next / Submit** with dark text, as on the website; teal call buttons.
- **Footer:** a charcoal band with the help line.
- **Font:** Figtree, the closest free match to the website's font.

To apply: paste the new `apprentice-signup.webtemplate.bnsw.liquid` into **Web Templates →
Apprentice Sign Up → Source**, **Save**, then **Sync** in Studio.

Settings at the top of the template:

| Setting | Default | Change it to |
|---|---|---|
| `asa_logo_url` | `''` (use the built-in logo) | an image address, if you'd rather use a different logo file, e.g. one uploaded as a Web File |
| `asa_privacy_url` | the ASA privacy policy (apprenticeshipsupport.com.au/privacy-policy) | `''` to hide the link |
| `asa_use_webfont` | `true` | `false` to stop loading Figtree from Google Fonts. The page then uses the device's own font and makes no outside calls. |

## Optional
- **Privacy link:** in both templates, change `{%- assign asa_privacy_url = '' -%}` near
  the top to your privacy policy address, e.g. `'https://www.asa.example/privacy'`.
  A "Privacy policy" link then appears in the footer.
- **Browser tab title and icon:** the tab shows the page name. Rename pages in Studio if
  needed, and set a favicon under Studio → Styling.
- **Custom domain:** e.g. `signup.<your-domain>`, once the site is converted to production.
