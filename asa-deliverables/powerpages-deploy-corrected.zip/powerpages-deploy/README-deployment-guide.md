# Deploying the Apprentice Sign-Up form to Power Pages

This isn't a one-click import. A Dataverse/Power Pages solution package has to be
generated *from* a live environment, so it can't be reliably hand-built offline. The
steps below build it in a dev/test environment first. Once it works, you export it as
a proper solution for production (step 7).

Allow roughly half a day to a day: creating ~60 columns, configuring security and
testing every branch.

## Before you start

- A Power Platform **environment with Dataverse** (dev/test first), in the region your
  data-residency requirement needs (e.g. Australia).
- An existing **Power Pages site** in that environment.
- **Power Pages licensing** for authenticated users (every applicant who signs in counts),
  plus Dataverse storage capacity.
- **Entra External ID** (or another identity provider) set up for external sign-in.
- Your solution **publisher prefix**. Every `asa_` in these files must be replaced with it.
- Someone with System Customizer (or higher) in the environment.

## Files in this folder

- `dataverse-table-schema.csv` — every column to create: type, choice values,
  Dataverse required setting, sensitive flag, and the conditional logic (`Shown When`)
  from the original MS Forms export.
- `apprentice-signup.webtemplate.liquid` — the full page (banner + 13-section wizard).
  It submits through the Power Pages Web API and requires sign-in.
- `security-and-permissions.md` — sign-in, Table Permissions, staff roles, column
  security, and the Web API site settings.
- `Create-ApprenticeSignUpTable.ps1` — PowerShell script that creates the table and all
  columns from the CSV (step 1).
- `Build-ApprenticeSignUpForm.ps1` — PowerShell script that lays out the staff form
  and main views (step 1b).
- `Configure-ApprenticeSignUpSecurity.ps1` — PowerShell script that creates the site
  settings, table permissions and column security profile (step 2).
- `Enable-TrackingCodeCheck.ps1` and `TRACKING-CODE-CHECK.md`: optional open form
  without sign-in, accepting only tracking codes ASA has issued (anonymous licence).
- `CHANGES.md` — what was fixed in this version and why.

## Steps

### 1. Create the table

**Scripted (recommended):** `Create-ApprenticeSignUpTable.ps1` builds the table from the CSV
in a few minutes. It sets the exact Choice values, the required levels and column
security, creates the Contact lookup, publishes the table and verifies the result.

1. Create an unmanaged solution under your publisher in make.powerapps.com
   (Solutions → New solution). Note its **Name** (unique name) and the publisher prefix.
2. Once, on the machine you'll run from: `Install-Module Az.Accounts -Scope CurrentUser`
3. Run the script, from this folder:

```powershell
# Preview offline — no sign-in, nothing created
.\Create-ApprenticeSignUpTable.ps1 -Prefix bnsw -PlanOnly

# Sign in and check the dev environment, but create nothing
.\Create-ApprenticeSignUpTable.ps1 -EnvironmentUrl https://yourorg-dev.crm6.dynamics.com `
    -SolutionUniqueName ApprenticeSignUp -Prefix bnsw -WhatIf

# Create it
.\Create-ApprenticeSignUpTable.ps1 -EnvironmentUrl https://yourorg-dev.crm6.dynamics.com `
    -SolutionUniqueName ApprenticeSignUp -Prefix bnsw
```

When it finishes it prints the relationship name for the Table Permission and the
`Webapi/<table>/fields` value. It also writes `apprentice-signup.webtemplate.<prefix>.liquid`,
the web template with your prefix, `ENTITY_SET` and `CONTACT_NAV` already filled in.
That takes care of most of step 4. It's safe to re-run: existing items are skipped and
re-verified. Run it in **dev only**; production gets the table through the solution (step 7).

**Sign-in problems or token errors:** add `-Relogin` to any of the scripts. It clears
the saved sign-in and signs you in again. Add `-TenantId businessnsw.com` if it signs you
into the wrong organisation. The scripts also re-login automatically if the saved
sign-in has expired.

If Windows blocks the script ("not digitally signed"), run
`Unblock-File .\Create-ApprenticeSignUpTable.ps1` first.

**Manual alternative:**
In [make.powerapps.com](https://make.powerapps.com) → your environment → **Solutions**
→ create (or open) an unmanaged solution under your publisher. Then **New → Table**
named `Apprentice Sign Up`.

Add each column from `dataverse-table-schema.csv`:

- **Lookup column first:** `Applicant (Contact)` → Lookup to **Contact**. Note its
  schema name (e.g. `asa_Contact`). You'll need it in step 4.
- **Choice columns:** set each option's **Value** to exactly the number in the CSV
  (e.g. NSW = 1). Dataverse otherwise auto-numbers options (e.g. 100000000), which
  won't match the page. In the choice editor, expand each option and edit its Value.
- **Required setting:** follow the `Required (Dataverse setting)` column. Conditional
  fields are deliberately *Optional* in Dataverse, because the form enforces them only
  when they're shown. Otherwise staff editing a record would be forced to fill in
  fields that don't apply.
- Mark the `Sensitive = Yes` columns for column security (see step 2).

### 1b. Lay out the staff form and views (scripted)
Run `Build-ApprenticeSignUpForm.ps1` with the same parameters as the table script.
It lays out the Main form as 4 tabs and 13 sections holding every column. It also sets
the columns of the "Active Apprentice Sign Ups" view and makes the search box find
tracking code, names, email, mobile and employer.

```powershell
.\Build-ApprenticeSignUpForm.ps1 -Prefix bnsw -PlanOnly          # preview offline
.\Build-ApprenticeSignUpForm.ps1 -EnvironmentUrl <url> -SolutionUniqueName <name> -Prefix bnsw -WhatIf
.\Build-ApprenticeSignUpForm.ps1 -EnvironmentUrl <url> -SolutionUniqueName <name> -Prefix bnsw
```

It **replaces** any tabs already laid out by hand on the Main form. A backup is saved
first (`form-backup-<date>.xml`), and `-RestoreFrom <backup file>` puts it back. You
can still tweak the result in the form designer afterwards.

### 2. Security & permissions

**Scripted (recommended):** `Configure-ApprenticeSignUpSecurity.ps1` creates:
- both Web API site settings;
- the Table Permission (Global, Create only), linked to the Authenticated Users web role;
- the staff column security profile for the 14 sensitive columns;
- optionally, your staff security role's access to the table (`-StaffRoleName`).

It works with both Power Pages data models and reads the real table and field names
from your environment before changing anything.

```powershell
.\Configure-ApprenticeSignUpSecurity.ps1 -Prefix bnsw -PlanOnly
.\Configure-ApprenticeSignUpSecurity.ps1 -EnvironmentUrl <url> -SolutionUniqueName <name> -Prefix bnsw `
    -WebsiteName "<site name>" -StaffRoleName "<staff role>" -WhatIf
# then the same without -WhatIf
```

It ends with a short list of what's still manual: adding staff to the profile, Power
Pages column permissions, page permissions and clicking Sync in Studio.

**Manual alternative:**
Follow `security-and-permissions.md` in order:
1. Sign-in provider + restrict the page to Authenticated Users.
2. One Table Permission (Apprentice Sign Up – Global access, Create only) on the
   Authenticated Users web role.
3. Staff security role for the model-driven app.
4. Column security profile for sensitive columns + matching Power Pages column permissions.
5. **Both** Web API site settings (`/enabled` and `/fields`).

### 3. Add the page
In Power Pages Studio, on your existing site:
1. **Set up → Web templates** (or the Portal Management app → Web Templates) → New.
   Paste the whole of `apprentice-signup.webtemplate.liquid`.
2. Create a **Page Template** that uses that Web Template.
3. **Pages → New page**, set its Page Template to the one above, and restrict it to
   Authenticated Users (Page permissions).

### 4. Fix the placeholders
If you used the script, paste the generated `apprentice-signup.webtemplate.<prefix>.liquid`
instead and skip to step 5. Otherwise, in the Web Template before publishing:
- Replace every `asa_` with your publisher prefix.
- `ENTITY_SET` (`"asa_apprenticesignups"`) must match the table's **Entity set name**
  (Table properties → Advanced options).
- `CONTACT_NAV` (`"asa_Contact"`) must match the Contact lookup's **schema name**,
  exactly, including capitals.
- Double-check the `values:{...}` maps match the Choice values you created.

### 5. Send applicants the link
Applicants can get a link with their tracking code pre-filled:

```
https://<your-site>/<page-path>?trackingcode=<CODE>
```

If they open the page without it, they paste the code in manually.

### 6. Test
Sign in as a test external user and submit several full passes, covering each
conditional branch at least once:

- has USI / no USI
- postal same as home / different
- Australian citizen / visa required
- still at school / finished school
- previously worked with business (full time / part time or casual)
- completed qualification / currently studying
- under 18 / not

Then confirm, in the model-driven app:
- the record exists and **Applicant (Contact)** is the test user;
- Choice and Date Only columns hold the right values;
- sensitive columns are populated, and hidden from staff not in the column security profile;
- a second test user cannot see the first user's record.

If the submit shows "Something went wrong", open the browser dev tools console. The
page logs the Web API's error message ("Apprentice sign-up submit failed …"), which
usually names the missing site setting, permission or column.

### 7. Promote dev → prod
Once verified, make sure the solution contains the table, the model-driven app/forms,
and the site components (Web Template, Page Template, web page, Table Permissions,
column permissions, site settings). Current Power Pages sites let you add the site to
a solution (Studio → Set up → Site details / Solutions). Export the solution as
**managed** and import it into production. Then re-check the sign-in provider and site
settings in the production site, since identity provider secrets are not carried over.
