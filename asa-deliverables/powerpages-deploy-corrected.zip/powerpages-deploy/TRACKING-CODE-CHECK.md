# Tracking-code check: an open form without sign-in

Applicants don't sign in. The form opens only for a **tracking code ASA has issued**,
and each code works **once**. The site uses the cheaper **anonymous** Power Pages
licence.

Replace `bnsw_` with your prefix if it differs.

## How it works

1. **Sign Up Invites** (new Dataverse table) holds every code you issue, with a status:
   **Issued**, **Used** or **Cancelled**, plus an optional expiry date.
2. **The page checks the code on the server** before showing anything:

   | Link | Applicant sees |
   |---|---|
   | No code | "Please use the personal sign-up link in the email we sent you." |
   | Unknown code | "We couldn't find this sign-up link…" |
| Cancelled code | "This sign-up link is no longer active…" |
   | Already used | "This sign-up has already been submitted…" |
   | Expired | "This sign-up link has expired…" |
   | Valid (Issued, not expired) | The form, with the code filled in and read-only |

3. **A Power Automate flow runs after each submission.** It re-checks the code, marks the
   invite **Used**, links the submission to its invite, and sets the submission's
   **Verification Status**: Verified, Invalid code, Code already used, or Code expired.
   This is the real enforcement. Even someone who bypasses the page and posts directly
   gets flagged, and staff only act on **Verified** records.

## Setup (about 1 hour)

### 1. Run the script
```powershell
.\Enable-TrackingCodeCheck.ps1 -EnvironmentUrl https://yourorg.crm6.dynamics.com `
    -SolutionUniqueName ASATestAIApp -Prefix bnsw -WebsiteName "ASA Sign Up" -WhatIf
# then again without -WhatIf
```

It creates:
- the Sign Up Invites table, with a unique key on the code;
- Verification Status and a Sign Up Invite lookup on Apprentice Sign Up;
- a read-only table permission on invites for the page's check;
- the Anonymous Users role on the Apprentice Sign Up create permission.

**If it prints ACTION NEEDED,** add those roles by hand in **Studio → Security → Table
permissions**. On your site the roles have previously needed adding manually. When
you're done, check:

| Table permission | Access | Privileges | Roles |
|---|---|---|---|
| Apprentice Sign Up - own records | Global | **Create** only | **Anonymous Users**, Authenticated Users |
| Sign Up Invite - code check | Global | **Read** only | **Anonymous Users**, Authenticated Users |

**Don't** add a `Webapi/bnsw_signupinvite/enabled` site setting. The invite table must
not be reachable through the Web API, or anyone could list your codes.

### 2. Open the page to everyone
**Studio → Pages → Sign Up → … → Page settings → Permissions:** remove the
*Authenticated Users* restriction, so the page is available to everyone.

### 3. Update the web template
Paste the new `apprentice-signup.webtemplate.bnsw.liquid` into **Power Pages
Management → Web Templates → Apprentice Sign Up → Source → Save**, then click **Sync**.

### 4. Build the verification flow (about 20 minutes)
In make.powerapps.com, go to **Solutions → ASATestAIApp → New → Automation → Cloud flow
→ Automated**. Name it `ASA Sign Up – verify tracking code`.

1. **Trigger:** Dataverse **When a row is added, modified or deleted**
   - Change type: **Added**. Table: **Apprentice Sign Ups**. Scope: **Organization**.
2. **Initialize variable**
   - Name `Result`, Type **Integer**, Value `3`. (3 = Invalid code, used if nothing matches.)
3. **Dataverse → List rows**
   - Table: **Sign Up Invites**. Row count: `1`.
   - Filter rows: type `bnsw_trackingcode eq '`, then insert this **expression**, then
     type a closing `'`:
     ```
     replace(triggerOutputs()?['body/bnsw_trackingcode'], '''', '''''')
     ```
4. **Condition:** expression `length(outputs('List_rows')?['body/value'])` **is greater than** `0`.

   **If yes:**
   1. **Compose**, renamed **Invite**: `first(outputs('List_rows')?['body/value'])`
   2. **Switch** on `outputs('Invite')?['bnsw_invitestatus']`:
      - **Case `1`** (Issued): add a **Condition** with the expression below,
        **is equal to** `true`:
        ```
        and(not(empty(outputs('Invite')?['bnsw_expireson'])), less(outputs('Invite')?['bnsw_expireson'], formatDateTime(utcNow(), 'yyyy-MM-dd')))
        ```
        - **Yes** (expired): **Set variable** `Result` = `5`.
        - **No** (valid):
          1. **Set variable** `Result` = `2`.
          2. **Dataverse → Update a row**: table **Sign Up Invites**, Row ID
             `outputs('Invite')?['bnsw_signupinviteid']`, **Invite Status = Used**,
             **Used On** = `utcNow()`.
      - **Case `2`** (Used): **Set variable** `Result` = `4`.
      - **Default** (Cancelled etc.): leave empty. Result stays 3.
   3. **Dataverse → Update a row**: table **Apprentice Sign Ups**, Row ID = the trigger's
      **Apprentice Sign Up** (unique identifier).
      **Sign Up Invite** = `bnsw_signupinvites(@{outputs('Invite')?['bnsw_signupinviteid']})`

   **If no:** nothing.
5. **After the condition**, add **Dataverse → Update a row**: table **Apprentice Sign
   Ups**, Row ID = the trigger's row ID, **Verification Status** → *Enter custom value* →
   `variables('Result')`.
6. **Save.** The flow turns on automatically.

**Licensing:** the Dataverse connector is premium. The flow's owner needs a Power Automate
Premium licence, or a Power Apps Premium licence (which covers flows for this app's data).

### 5. Create tracking codes (generated automatically)
Codes are **generated by Dataverse** whenever a Sign Up Invite row is created. Leave the
code blank and you get something like **`ASA-10001-K7Q2ZP`**:

- `ASA-` is a fixed prefix.
- `10001` is a running number, so codes never clash.
- `K7Q2ZP` is 6 random characters, so codes can't be guessed.

To change the pattern, re-run the script with `-CodeFormat`.

**One at a time (staff):**
1. In the staff app, go to **Sign Up Invites → + New**.
2. Enter **Applicant Name** and **Email Sent To**. Leave the code blank and Invite Status
   as Issued. Click **Save**.
3. The code appears. The applicant's link is:
   `https://<your-site>/sign-up/?trackingcode=<code>`

**In bulk:**
1. Go to **Tables → Sign Up Invites → Import → Import data from Excel**.
2. Use one row per applicant with **Applicant Name** and **Email Sent To**, and leave the
   code column blank. Each row gets its own code on import.
3. Export the view to Excel to get the codes for a mail merge, or use the email flow below.

**Codes already issued by the old form:** if applicants still hold old links, import those
codes **with** the code filled in (Invite Status = Issued) so they keep working.

**Optional: email the link automatically (about 10 minutes).** In the solution, go to
**New → Automation → Cloud flow → Automated**:
1. **Trigger:** Dataverse **When a row is added, modified or deleted**. Change type
   **Added**, table **Sign Up Invites**, scope **Organization**.
2. **Condition:** **Email Sent To** is not equal to *(blank)*.
3. **If yes:** Office 365 Outlook **Send an email from a shared mailbox (V2)**.
   - Mailbox: your ASA sign-up mailbox. To: **Email Sent To**.
   - Subject: `Your apprenticeship sign-up link`
   - Body, for example:
     > Hi @{triggerOutputs()?['body/bnsw_applicantname']},
     >
     > Please provide your details for your apprenticeship / traineeship sign-up:
     > https://<your-site>/sign-up/?trackingcode=@{triggerOutputs()?['body/bnsw_trackingcode']}
     >
     > This link is personal to you — please don't share it.
     > For assistance call 1300 363 831.

With this flow, staff just add a row (or import a list) and the applicant receives their
link within a minute.

### 6. Staff view
Add **Verification Status** to the *Active Apprentice Sign Ups* view. Consider a second
view, **Needs review**, showing records where Verification Status ≠ Verified.
Periodically delete records flagged *Invalid code*.

Also add **Sign Up Invites** to the staff app so staff can add, cancel or extend codes.

## Test checklist (fresh private window, not signed in)
1. **`/sign-up/` with no code** shows the "use your link" message.
2. **`/sign-up/?trackingcode=NOTREAL`** shows "couldn't find".
3. **Add an invite** (leave the code blank) and note the generated code. Opening
   `?trackingcode=<that code>` shows the form with the code read-only. Submit, and you get the green tick.
4. **Within about a minute:** the submission shows **Verified** and is linked to the invite,
   and the invite shows **Used** with *Used On* set.
5. **Open the same link again:** "already submitted". The page may take a few minutes to
   notice because of site caching; a second submission in that window is flagged
   *Code already used*.
6. **Set an invite's Expires On to yesterday:** "expired".
7. **Set an invite to Cancelled:** "no longer active".

## Troubleshooting
- **A code you just cancelled, used or expired still opens the form:** the page's code lookup
  bypasses the site cache, so this shouldn't happen. If it does, clear the cache: sign in as an
  admin, open `/_services/about` and click **Clear cache**. A form already open in a browser can
  still be submitted; the flow then flags it **Invalid code**.
- **Every valid code says "couldn't find":** the *Sign Up Invite - code check*
  permission is missing the **Anonymous Users** role, or you haven't clicked Sync.
- **Submit fails with 403:** the Apprentice Sign Up permission is missing **Anonymous
  Users**. The *Technical details* link on the error screen shows the exact error.
- **Records stay "Pending":** the flow isn't on or has failed. Check its run history in
  Power Automate.

## Licensing impact
Once no page needs sign-in, the site uses **anonymous** capacity:
**AU$112.20 per 500 users per site per month** (list price, ex GST), instead of the
authenticated packs.
