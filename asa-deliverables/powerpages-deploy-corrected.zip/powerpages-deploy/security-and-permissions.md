# Security & permissions — Apprentice Sign-Up

Keeps this data inside your organisation's tenant boundary with proper access control,
instead of MS Forms' default handling.

Replace `asa_` with your publisher prefix everywhere below.

> Sections 2, 4 (the column security profile) and 5 can be done for you by
> `Configure-ApprenticeSignUpSecurity.ps1`. This document describes what it creates,
> and is the manual fallback.

## 1. Sign-in for external applicants (required)

The page only works for signed-in users: each submission is linked to the applicant's
Contact record, and anonymous visitors see a "Sign in to continue" prompt instead of
the form.

- **Sign-in provider:** Entra External ID is recommended (every record tied to a real
  identity, MFA available, audit trail). Configure under
  **Power Pages Studio → Set up → Identity providers**.
- **Page permission:** in Studio, open the Sign-Up page → **Permissions** → restrict to
  the **Authenticated Users** web role. Anonymous access must not be used for this form:
  it captures USI, citizenship/visa, Indigenous status, disability and (for minors)
  parent/guardian details.

## 2. Table Permission (what website users can do)

Table Permissions only govern **website (portal) users**. They do not affect staff in
the model-driven app; see section 3 for staff.

Create this in **Power Pages Studio → Security → Table permissions**:

| Setting | Value |
|---|---|
| Name | Apprentice Sign Up - own records |
| Table | Apprentice Sign Up (`asa_apprenticesignup`) |
| Access type | **Global access** |
| Privileges | **Create** only (no Read, Write, Delete, Append or Append To) |
| Roles | **Authenticated Users** (check the Roles column isn't empty) |

- A signed-in applicant can **submit** a record but can't read, change or delete any
  record, including their own.
- **Why not Contact scope?** Contact scope needs the new record linked to the
  applicant's Contact as it's created. In testing, Power Pages refused that link
  (error 90040106) even with Append/Append To on both tables. So the form doesn't set
  the Applicant (Contact) lookup (`LINK_CONTACT = false` in the web template).
  Applicants are identified by tracking code and email. To populate the Applicant
  lookup later, use a background Power Automate flow instead.
- After any permission change, click **Sync** in Studio and sign in again in a fresh
  browser window before testing.

## 3. Staff access (model-driven app)

Caseworkers use normal **Dataverse security roles**, not Table Permissions. In the
Power Platform admin centre → Environment → **Security roles**, give your staff role(s)
(e.g. "ASA Case Managers") Organisation- or Business Unit-level Read/Write on
**Apprentice Sign Up**. Then add the table to your model-driven app.

## 4. Column-level security for sensitive fields

The columns marked `Sensitive = Yes` in `dataverse-table-schema.csv` are USI,
date of birth, citizenship, visa details, Indigenous status, disability and all
parent/guardian fields. They should be restricted with Dataverse column security:

1. In each sensitive column's properties, tick **Enable column security**.
2. Create a **Column security profile** (admin centre → Security → Column security
   profiles) granting Read/Update/Create on those columns. Add only the staff
   users or teams who should see them.

**Important — the website must still be able to write these columns.** Once column
security is on, Power Pages also needs **column permissions** or the submit may fail
for those fields:

- Power Pages Studio → Security → **Column permissions** → New.
- Table: Apprentice Sign Up. Add every sensitive column with **Create** (plus **Read**
  if you want applicants to be able to read back their own submission).
- Assign to the **Authenticated Users** web role.

Test a full submission (including the under-18 and visa branches) after enabling
column security, and confirm the sensitive values arrive in Dataverse.

## 5. Web API site settings (both required)

Add these in **Power Pages Management app → Site Settings** (or Studio → Set up → Site
settings) for your website:

| Name | Value |
|---|---|
| `Webapi/asa_apprenticesignup/enabled` | `true` |
| `Webapi/asa_apprenticesignup/fields` | the column list below |

`Webapi/asa_apprenticesignup/fields`, with the prefix replaced (one line, no spaces):

```
asa_contact,asa_trackingcode,asa_hasusi,asa_usinumber,asa_usipermission,asa_firstname,asa_middlename,asa_lastname,asa_previousname,asa_dateofbirth,asa_homestreet,asa_homesuburb,asa_homepostcode,asa_homestate,asa_postalsame,asa_postaladdress,asa_postalsuburb,asa_postalpostcode,asa_mobile,asa_email,asa_gender,asa_citizenship,asa_visadetails,asa_countryofbirth,asa_languageathome,asa_indigenousstatus,asa_disability,asa_stillatschool,asa_schoollevel,asa_highestschooling,asa_monthcompletedschool,asa_yearcompletedschool,asa_employer,asa_apprenticeshipstartdate,asa_jobtitle,asa_qualification,asa_commencedbefore,asa_previouslyworkedwithbusiness,asa_priorworkstarted,asa_priorworkended,asa_priorworkemploymenttype,asa_priorworkhoursperweek,asa_workplacename,asa_workplaceaddress,asa_completedqualification,asa_qualificationdetails,asa_qualificationstudystarted,asa_qualificationstudyfinished,asa_currentlystudying,asa_currentstudyname,asa_currentstudystartdate,asa_under18,asa_guardianfirstname,asa_guardianlastname,asa_guardianaddress,asa_guardiansuburb,asa_guardianstate,asa_guardianpostcode,asa_guardianmobile,asa_guardianemail
```

Without `/enabled` the submit returns 404. Without `/fields` it is rejected with a
"not enabled for Web API" error. Listing columns explicitly is safer than `*`.


## 6. Data residency

Dataverse stores data in the region your Power Platform **environment** is provisioned
in, within your Entra ID tenant boundary. Confirm the target environment's region
(e.g. Australia) matches your residency requirement before building the table there.
The page makes no calls to external services (the previous Google Fonts dependency has
been removed).
